#! /usr/bin/perl
use strict;

die "perl $0 <input> <bed>\n"  unless @ARGV==2;

my %bed;
open BED, $ARGV[1] or die $!;
while(<BED>){
	chomp;
	my @tmp = split /\s+/, $_;
	$bed{$tmp[0]}{$tmp[1]} = $tmp[2];
}
close BED;

my %region;
open IN, $ARGV[0] or die $!;
while(<IN>){
	chomp;
	my @tmp = split /\s+/, $_;
	my $c5 = $tmp[4];
	$c5 =~ /#(\w+)-(\d+)-(\d+)/;
	$region{$1}{$2}{$3} = 0;
}
close IN;


foreach my $chr(sort keys %region){
	my ($last_beg, $last_end) = (0,0);
	foreach my $beg (sort {$a<=>$b} keys %{$region{$chr}}){
		foreach my $end (sort {$a<=>$b} keys %{$region{$chr}{$beg}}){
			my $len = $end - $beg +1;
			if ($len >= 20000 and $len <= 50000 ){
				$region{$chr}{$beg}{$end} = 1;
			}elsif($len <20000){
				my $key = 0;
				foreach my $start (sort {$a<=>$b} keys %{$bed{$chr}}){
					my $stop = $bed{$chr}{$start};
					if ($beg > $stop){
						delete $bed{$chr}{$start};
						next;
					}elsif($end < $start){
						last;	
					}else{
						$key = 1;
						last;
					}
				}
				$region{$chr}{$beg}{$end} = 1 if $key ==0;
			}elsif($len >50000){
				if($beg >= $last_end){
					($last_beg, $last_end) = ($beg, $end);
					next;
				}elsif($beg < $last_end and $end >= $last_end){
					if($last_end - $beg >=1000){
						$region{$chr}{$last_beg}{$last_end} = 1;
						$region{$chr}{$beg}{$end} = 1;
					}
					($last_beg, $last_end) = ($beg, $end);
				}elsif($end < $last_end){
					$region{$chr}{$last_beg}{$last_end} = 1;
					$region{$chr}{$beg}{$end} = 1;
				}
			}
		}	
	}
}
open IN, $ARGV[0] or die $!;
while(<IN>){
    chomp;
	my @tmp = split /\s+/, $_;
	my $c5 = $tmp[4];
	$c5 =~ /#(\w+)-(\d+)-(\d+)/;
	if ($region{$1}{$2}{$3} == 1){
		print $_,"\n";
	}
}
close IN;

	
