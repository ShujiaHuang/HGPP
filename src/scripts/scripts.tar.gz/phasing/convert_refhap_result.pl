#!/usr/bin/perl

use strict;
use warnings;

die "The arguments are: $0 <seperate_chr docu path> <refhap_format docu path> <refhap_result docu path> <output_docu path>" if(@ARGV!=4);

my $seperate_chr = $ARGV[0];
my $refhap_format_docu = $ARGV[1];
my $refhap_result_docu = $ARGV[2];
my $output_docu = $ARGV[3];

my @file;
opendir DH1,"$refhap_result_docu" or die "Cann't open the document: $refhap_result_docu";
foreach my $file (readdir DH1){
	if($file=~/\.phase$/){
		$file =~ s/\.phase//;
		push @file,$file; 
	}else{
		next;
	}
}
closedir DH1;
################################################################################################################################
foreach my $file (@file){
	my (%hash,$chr);
	open IN1,"$seperate_chr/$file" or die "$!";
	while(<IN1>){
		chomp;
		my @array = split /\t+/;
		$chr = $array[0] if(!defined $chr);
		my @position = split /,/,$array[1];
		$array[3]=~s/:\d+//g;
		$array[3]=~tr/[a-z]/[A-Z]/;
		my @phase = split /,/,$array[3];

		foreach my $i (0..$#position){
			$hash{$array[4]}{$position[$i]} = $phase[$i];
		}
	}
	close IN1;	
################################################################	
	my (@position,%phase);
	open IN2,"$refhap_format_docu/$file.H" or die "$!";
	while(<IN2>){
    	chomp;
		my @array = split /\t+/;
		push @position,$array[1];
		$phase{$array[1]}[0] = $array[3];
		$phase{$array[1]}[1] = $array[4] eq "*"?"-":$array[4];
		if(length($array[3]) eq "1" && length($array[4]) eq "1"){
			$phase{$array[1]}[2] = &combine_snp($array[3],$array[4]);
		}else{
			$phase{$array[1]}[2] = &combine_indel($array[3],$array[4]);
		}
    }
	close IN2;
##################################################################################
	my (%haplotype1,%haplotype2);
	my $unphase_num = 0;
	my $phase_num = 0;
	open IN3,"$refhap_result_docu/$file.phase" or die "$!";
	while(<IN3>){
		chomp;
		if($_=~/^BLOCK:/){
			next;
		}elsif($_=~/^\*/){
			last;
		}else{
			my @array = split /\t+/;
			if($array[1] eq "-" && $array[2] eq "-"){
				$haplotype1{$array[0]} = "-";
				$haplotype2{$array[0]} = "-";
				$unphase_num++;
			}else{
				$phase_num++;
				$haplotype1{$array[0]} = $phase{$array[0]}[$array[1]];
				$haplotype2{$array[0]} = $phase{$array[0]}[$array[2]];
			}
		}
	}
	close IN3;
######################################################################################
	my (@hap1_f,@hap2_f);
	foreach my $f (keys %hash){
		my $consis1 = 0;
		my $consis2 = 0;
		foreach my $pos (keys %{$hash{$f}}){
			if($hash{$f}{$pos} eq $haplotype1{$pos}){
				$consis1++;
			}elsif($hash{$f}{$pos} eq $haplotype2{$pos}){
				$consis2++;
			}
		}
		
		if($consis1>=$consis2){
			push @hap1_f,$f;
		}else{
			push @hap2_f,$f;
		}
	}

	my (@fragment1_pos,@fragment2_pos);
	foreach my $f (@hap1_f){
		my @array = split /,/,$f;
		if(@array==1){
			$array[0]=~m/#\S+-(\d+)-(\d+)/;
			push @fragment1_pos,$1,$2;
		}else{
			foreach my $i (@array){
				$i=~m/#\S+-(\d+)-(\d+)/;
				push @fragment1_pos,$1,$2;
			}
		}
	}

	foreach my $f (@hap2_f){
		my @array = split /,/,$f;
		if(@array==1){
			$array[0]=~m/#\S+-(\d+)-(\d+)/;
			push @fragment2_pos,$1,$2;
		}else{
			foreach my $i (@array){
				$i=~m/#\S+-(\d+)-(\d+)/;
			push @fragment2_pos,$1,$2;
			}
		}
	}
##########################################################################
	@fragment1_pos = sort {$a <=> $b} @fragment1_pos;
	@fragment2_pos = sort {$a <=> $b} @fragment2_pos;

#	print STDERR "$file has problem that all fragments only locate on one haplotype\n" if(@fragment1_pos eq "0" || @fragment2_pos eq "0");

	my (@haplotype1,@haplotype2,@phase);
	foreach my $pos (sort {$a <=> $b} keys %haplotype1){
		push @haplotype1,$haplotype1{$pos};
	}
	foreach my $pos (sort {$a <=> $b} keys %haplotype2){
		push @haplotype2,$haplotype2{$pos};
    }
	foreach my $pos (sort {$a <=> $b} keys %phase){
		push @phase,$phase{$pos}[2];
	}

	my $total_num = $unphase_num+$phase_num;
	my ($start,$end);
	open OUT,">$output_docu/$file.v" or die "Cann't open the file: $output_docu/$file.v";
	if(@fragment1_pos ne "0"){
		$start = $fragment1_pos[0]<$position[0]?$fragment1_pos[0]:$position[0];
		$end = $fragment1_pos[$#fragment1_pos]>$position[$#position]?$fragment1_pos[$#fragment1_pos]:$position[$#position];
		print OUT "$chr\t$start\t$end\t$phase_num/$total_num\t",join ",",@position;
	}else{
		$start = $position[0];
		$end = $position[$#position];
		print OUT "$chr\t$start\t$end\t$phase_num/$total_num\t",join ",",@position;
	}
	print OUT "\t",join ",",@haplotype1;
	print OUT "\t",join ",",@phase;
	print OUT "\t1\t";
	if(@hap1_f>0){
		print OUT join ",",@hap1_f;
	}else{
		print OUT "-";
	}
	print OUT "\n";

	if(@fragment2_pos ne "0"){
		$start = $fragment2_pos[0]<$position[0]?$fragment2_pos[0]:$position[0];
		$end = $fragment2_pos[$#fragment2_pos]>$position[$#position]?$fragment2_pos[$#fragment2_pos]:$position[$#position];
		print OUT "$chr\t$start\t$end\t$phase_num/$total_num\t",join ",",@position;
	}else{
		$start = $position[0];
		$end = $position[$#position];
		print OUT "$chr\t$start\t$end\t$phase_num/$total_num\t",join ",",@position;
	}
	print OUT "\t",join ",",@haplotype2;	
	print OUT "\t",join ",",@phase;
	print OUT"\t1\t";
	if(@hap2_f>0){
		print OUT join ",",@hap2_f;
	}else{
		print OUT "-";
	}
	print OUT "\n";
	close OUT;
}
#################################################################################################################################
sub combine_snp {
	my ($allele1,$allele2)=@_;
	my $phase = $allele1.$allele2;
	my $combine;
	if($phase eq "CG"){
		$combine = "S";
	}elsif($phase eq "AC"){
		$combine = "M";
	}elsif($phase eq "GT"){
		$combine = "K";
	}elsif($phase eq "AG"){
		$combine = "R";
	}elsif($phase eq "AT"){
		$combine = "W";
	}elsif($phase eq "CT"){
		$combine = "Y";
	}
	return $combine;
}

sub combine_indel {
	my ($indel1,$indel2)=@_;
	my $combine;
	if(length($indel2) eq "1"){
		$combine = $indel1;
	}elsif(length($indel1) eq "1"){
		$combine = $indel2;
	}else{
		$combine = "$indel1/$indel2";
	}
	return $combine;
}
