#!/usr/bin/perl

use strict;
use warnings;

die "The arguments are: $0 <input file dir> <output file dir>." if(@ARGV!=2);
my $input_dir = $ARGV[0];
my $output_docu = $ARGV[1];
mkdir $output_docu unless -d $output_docu;

my @file=();
opendir DH,"$input_dir" or die "Can't open:$!";
foreach my $file (readdir DH){
	push @file,$file if($file=~m/\.ref$/);
}
closedir DH;
#########################################################################################
foreach my $file (@file){
	open IN,"$input_dir/$file" or die "Can't open file: $!";
	my @read=();
	my %pos_phase=();
	my $chr;
	my (@fragment,@fragment_start,@fragment_end)=();

	while(<IN>){
		chomp($_);
		my @array=split /\t+/;
		$chr=$array[0];
		my @position=split /,/,$array[1];
		my @phase=split /,/,$array[2];
		foreach my $pos (0..$#position){
			$pos_phase{$position[$pos]}=$phase[$pos] if(!defined $pos_phase{$position[$pos]});
		}
		push(@read,$_);
#		$array[4] =~ m/#\S+-(\d+)-(\d+)$/;
	}
	close IN;
	&convert(\@read,\%pos_phase,$chr,$output_docu,$file);
}
#############################################################################
sub convert{
	my ($ref_read,$ref_pos_phase,$chr,$dir,$file)=@_;
	my @position = sort {$a <=> $b} keys %$ref_pos_phase;
	my %pos2order=();
	my $order=1;

	open OUT,">$dir/$file.H" or die "$!";
	foreach my $pos (@position){
		my $ref_allele=&replace_combine_phase($ref_pos_phase->{$pos});
		my $num=keys %$ref_allele;
		$pos2order{$pos}=$order;
		$order++;
		if($num eq "1" && $ref_allele->{0}=~m/(\+|\-)/){
			print OUT join "\t",($chr,$pos,$pos,$ref_allele->{0},"*","INDEL"),"\n";
		}elsif($num eq "2" && $ref_allele->{0}=~m/(\+|\-)/){
			print OUT join "\t",($chr,$pos,$pos,$ref_allele->{0},$ref_allele->{1},"INDEL"),"\n";
		}else{
			print OUT join "\t",($chr,$pos,$pos,$ref_allele->{0},$ref_allele->{1},"SNP"),"\n";
		}
	}
	close OUT;
	
	my %output_read;
	foreach my $read (@$ref_read){
		my @array=split/\t+/,$read;
		
		my @read_position=split/,/,$array[1];
		$array[2]=~tr/[a-z]/[A-Z]/;
		my @read_phase=split/,/	,$array[2];
		$array[3]=~tr/[a-z]/[A-Z]/;
		$array[3]=~s/:\d+//g;
		my @read_allele=split/,/,$array[3];
		my $fragment = $array[4];


		my %base=();
		foreach my $k (0..$#read_position){
			$base{$read_position[$k]}[0]=$read_phase[$k];
			$base{$read_position[$k]}[1]=$read_allele[$k];
		}

		my %convert=();
		foreach my $k (sort {$a <=> $b} keys %$ref_pos_phase){
			if(exists $base{$k}){
				my $know=&replace_combine_phase($base{$k}[0]);
				my $num=keys %$know;
				if($num eq "2"){
					$convert{$k}=0 if($base{$k}[1] eq "$know->{0}");
					$convert{$k}=1 if($base{$k}[1] eq "$know->{1}");
				}else{
					$convert{$k}=0;
				}
			}else{
				$convert{$k}="*";
			}
		}

		my $read_start;
		my @sort_position=sort {$a <=> $b} keys %convert;
		foreach my $k (@sort_position){
			if($convert{$k} ne "*"){
				$read_start=$k;
				last;
			}
		}
		my $line;
		for(my $i=0;$i<@sort_position;$i++){
			if($convert{$sort_position[$i]} eq "*"){
				next;
			}elsif($i==0 && $convert{$sort_position[$i]} ne "*"){
				$line="$pos2order{$sort_position[0]}\t$convert{$sort_position[0]}";
			}elsif($i!=0 && $convert{$sort_position[$i-1]} ne "*" && $convert{$sort_position[$i]} ne "*"){
				$line=$line."$convert{$sort_position[$i]}";
			}elsif($i!=0 && $convert{$sort_position[$i-1]} eq "*" && $convert{$sort_position[$i]} ne "*"){
				$line=$line."\t$pos2order{$sort_position[$i]}\t$convert{$sort_position[$i]}" if(defined $line);
				$line="$pos2order{$sort_position[$i]}\t$convert{$sort_position[$i]}" if(!defined $line);	
			}
		}
		$output_read{$line}[0]++;
		$output_read{$line}[1]=$read_start;
		push @{$output_read{$line}[2]},$fragment;	
	} 	
	open OUT1,">$dir/$file.F" or die "$!";
#	open OUT2,">$dir/$file.L" or die "$!";
	my @order= sort {$output_read{$a}[1] <=> $output_read{$b}[1]} keys %output_read;
	my $id=1;
	foreach my $k (@order){
		print OUT1 "$output_read{$k}[0]\t$chr\_$id\t$k\n";
#		if(@{$output_read{$k}[2]}==1){
#			print OUT2 "$chr\_$id\t$output_read{$k}[2][0]\n";
#		}else{
#			print OUT2 "$chr\_$id\t",join ",",@{$output_read{$k}[2]};
#			print OUT2 "\n";
#		}
		$id++;
	}
}
#############################################################################
sub replace_combine_phase{
	my $phase=$_[0];
	my %combine=();	

	if($phase eq "S"){
		$combine{0}="C";
		$combine{1}="G";
	}elsif($phase eq "M"){
		$combine{0}="A";
		$combine{1}="C";
	}elsif($phase eq "K"){
		$combine{0}="G";
		$combine{1}="T";
	}elsif($phase eq "R"){
		$combine{0}="A";
		$combine{1}="G";
	}elsif($phase eq "W"){
		$combine{0}="A";
		$combine{1}="T";
	}elsif($phase eq "Y"){
		$combine{0}="C";
		$combine{1}="T";
	}else{
		$phase=~tr/[a-z]/[A-Z]/;
		if($phase=~m/\|/){
			my @array=split/\|/,$phase;
			$combine{0}=$array[0];
			$combine{1}=$array[1];
		}else{
			$combine{0}=$phase;
		}
	}
	return(\%combine);
}
##################################################################################################
