#! /usr/bin/perl
use strict;

my %hash;
open IN, $ARGV[0] or die $!;
while(<IN>){
	chomp;
	my @tmp = split /\s+/, $_;
	my $chr = $tmp[0];
	my @c2 = split /,/, $tmp[1];

	if ($hash{$chr}{$c2[0]}){
		$hash{$chr}{$c2[0]} .= "\n";
	}
	$hash{$chr}{$c2[0]} .= $_;
}
close IN;

foreach my $chr ( sort keys %hash){
	foreach my $pos (sort {$a<=>$b} keys %{$hash{$chr}}){
		print $hash{$chr}{$pos},"\n";
	}
}
