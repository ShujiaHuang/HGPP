#!/usr/bin/perl

use strict;
use warnings;

die "The arguments are: $0 <input file> <output dir> <threshold>." if(@ARGV!=3);
my $input=$ARGV[0];
my $output=$ARGV[1];
my $threshold=$ARGV[2];

mkdir $output unless -d $output;

##################################################################################################
my @all_position=();
my @reads=();
my $output_file_id=1;
my $end;

open IN,"$input" or die "Can't open file: $!";
while(<IN>){
	chomp($_);
	my @array=split/\t+/;
	my @position=split/,/,$array[1];
	if(@reads==0){
		$end=$position[$#position];
		push(@all_position,@position);
		push(@reads,$_);
	}else{
		if($end>$position[0]){
			push(@all_position,@position);
			push(@reads,$_);
			my %hash=();
			@all_position=grep {!$hash{$_}++} @all_position;
			@all_position=sort {$a <=> $b} @all_position;
			$end=$all_position[$#all_position];
		}else{
			&identity_output(\@reads,\$output_file_id,$output);
			@reads=();
			@all_position=();
			$end=$position[$#position];
			push(@all_position,@position);
			push(@reads,$_);
		}
	}
}
&identity_output(\@reads,\$output_file_id,$output);
close IN;
print STDERR "$input reads seperate complete\n";
###########################################################################################################################
sub identity_output{
	my ($ref_read,$output_file_id,$dir)=@_;
	my $ref_read_num=@$ref_read;	
	while($ref_read_num ne "0"){
		my $ref=&repeat($ref_read,$output_file_id,$dir);	
		$ref_read_num=@$ref;
	}
}
#########################################################################################################################
sub repeat{
	my ($ref_read,$output_file_id,$dir)=@_;
	my $first_read=$ref_read->[0];
	my @first_array=split/\t+/,$first_read;
	my @first_position=split/,/,$first_array[1];
	
	my @all_position=();
	push @all_position,[@first_position];

	my %output=();
	$output{$first_read}=$first_position[0];
	splice(@$ref_read,0,1);	
	my $all_num=@$ref_read;	

	for(my $j=0;$j<$all_num;$j++){
		my $num1=@$ref_read;
		for(my $i=0;$i<@$ref_read;$i++){
			my $num;
			my $second_read=$ref_read->[$i];
			my @second_array=split/\t+/,$second_read;
			my @second_position=split/,/,$second_array[1];

			foreach my $k (@all_position){
				$num=0;
				next if($k->[$#$k]<$second_position[0]);
				foreach my $m (@$k){
					last if($num>=$threshold);
					foreach my $n (@second_position){
						if($m eq "$n"){
							$num++;
							last;	                   
						}else{
							next;
						}
					}
				}
				last if($num>=$threshold);
			}

			if($num>=$threshold){
				$output{$second_read}=$second_position[0];
				$ref_read->[$i]="*";
				push(@all_position,[@second_position]);			
			}else{
				next;
			}		
		}
		@$ref_read =grep {$_ ne "*"} @$ref_read;
		my $num2=@$ref_read;
		last if($num1==$num2);
	}

	my @sort_pos=sort {$output{$a} <=> $output{$b}} keys %output;
	print STDERR "read_$$output_file_id.ref reads num:\t",@sort_pos."\n";
	open OUT,">$dir/read_$$output_file_id.ref" or die "$!";
	foreach my $key (0..$#sort_pos){
		print OUT "$sort_pos[$key]";
		print OUT "\n" if($key ne "$#sort_pos");
	}
	close OUT;
	$$output_file_id++;
	return ($ref_read);
}
###########################################################################################################################
