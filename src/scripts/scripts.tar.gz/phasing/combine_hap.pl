#!/usr/bin/perl

use strict;
use warnings;

use Getopt::Long;

my ($dir,$outfile);
GetOptions(
	"in:s" => \$dir,
	"out:s" => \$outfile,
);

if(!$dir || !$outfile){
	usage();
	exit(1);
}
sub usage{
	print STDERR<<USAGE;
	-in  <option> The refhap convert result dir.
 	-out <option> The outputfile.
USAGE
}
########################################################
open OUT,">$outfile" or die "$!";

opendir DH,"$dir" or die "$!";
my $i = 1;
foreach my $file(readdir DH){
	next unless ($file=~/\.v$/);
	open IN,"$dir/$file" or die "$!";
	while(<IN>){
		chomp;
		my @array = split /\t+/;
		$array[0] = $array[0]."_$i";
		$i++;
		print OUT join "\t",@array;
		print OUT "\n";
	}
}
closedir DH;
close OUT;
