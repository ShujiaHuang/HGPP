#! /usr/bin/perl -w
use strict;

my %jianbing = (
	"A,G" => "R", "G,A" => "R",
	"C,T" => "Y", "T,C" => "Y",
	"A,C" => "M", "C,A" => "M",
	"G,T" => "K", "T,G" => "K",
	"C,G" => "S", "G,C" => "S",
	"A,T" => "W", "T,A" => "W",
);

my %var;
open TOTAL, $ARGV[0] or die $!;
while(<TOTAL>){
	chomp;
	my @tmp = split /\s+/, $_;
	my ($chr, $pos, $ref, $alt) = @tmp[0,1,3,4];
	$ref = uc $ref;
	$alt = uc $alt;
	my $new_alt = $alt;
	if ($new_alt =~ /,/){
		if (length($new_alt) ==3){
			$new_alt = $jianbing{$new_alt};
			$var{$chr}{$pos} = "$ref:$new_alt";
		}else{
			next;
		}
	}else{
		if (length $ref >1){
			$ref =~ /\w(\w+)/;
			$new_alt = "-$1";
			$ref = "*";
		}elsif(length $alt >1){
			$alt =~ /\w(\w+)/;
			$new_alt = "+$1";
			$ref = "*";
		}else{
			next if $ref eq "N";
			$new_alt = $jianbing{"$ref,$new_alt"};
		}
		$var{$chr}{$pos} = "$ref:$new_alt";
	}
}
close TOTAL;


my %plist;
open  PLIST, $ARGV[1] or die $!;
while(<PLIST>){
	chomp;
	my $basename = (split /\//, $_)[-1];
	$basename =~ /(.+)\.pileup/;
	my $pool = $1;
	$plist{$pool} = $_;
}
close PLIST;


my %region;
open RLIST, $ARGV[2] or die $!;
while(<RLIST>){
	chomp;
	my $filename = $_;
	my $basename = (split /\//, $filename)[-1];
	$basename =~ /(.+)\.fosmid\.region/;
	my $pool = $1;

	open REGION, $filename or die $!;
	while(<REGION>){
		chomp;
		my ($chr, $beg, $end) = (split /\s+/, $_)[1,2,3];
		#next unless $chr eq "chr6";
		#next if ($end <= 28477797 or $beg >= 33448354);
		$region{$pool}{$chr}{$beg}=$end;
	}
	close REGION;
}
close RLIST;


my %out;
foreach my $key (keys %region){
	next unless exists $plist{$key};
	my %hash1;
	my %hash2;
	open PILEUP, $plist{$key} or die $!;
	my $last_ref;
	while(<PILEUP>){
		chomp;
		my ($chr, $pos, $ref, $base, $detail) = (split /\s+/,$_)[0,1,2,3,8];
		#next unless $chr eq "chr6";
		#next if ($pos <= 28377797 or $pos >= 33548354);
		$ref = uc $ref;
		$base = uc $base;
		$ref = $last_ref if $ref eq "*";
		$hash1{$chr}{$pos} = "$ref:$base";
		$hash2{$chr}{$pos} = $detail;
		$last_ref = $ref;
	}
	foreach my $chr(keys %hash1){
		foreach my $pos (keys %{$hash1{$chr}}){
			my $info = $hash1{$chr}{$pos};
			my $ref = (split /:/, $info)[0];
			my $base = (split /:/, $info)[1];
			if ($base =~ /\//){ #indel
				if ($base eq "*/*"){
					$hash1{$chr}{$pos} = "$ref:$ref";
				}elsif($base =~ /\*\/(.+)/ or $base =~ /(.\w+)\/.+/){
					my $alle = $1;
					$hash1{$chr}{$pos} = "$ref:$alle";
				}
			}else{	#snp
				if ($base =~ /[A|T|G|C]/){
					next;
				}else{
					my @bases = split //, $hash2{$chr}{$pos};
					my (%num1, %num2);
					$num1{","} = 0;
					$num1{"."} = 0;
					for(my $i=0; $i<@bases; $i++){
						my $tmp_base = $bases[$i];
						$num1{$tmp_base}++;

						$tmp_base = uc $tmp_base;
						if (($tmp_base eq ",") or ($tmp_base eq ".")){
							next;
						}elsif($tmp_base =~ /[A|T|G|C]/){
							$num2{$tmp_base}++;
						}
					}
					my $first; my $last=0; 
					foreach my $key (keys %num2){
						if ($num2{$key} > $last){
							$last = $num2{$key};
							$first = $key;
						}else{
							next;
						}
					}
					my $lowcase;
					if (exists $num1{$first}){
						$lowcase = $num2{$first} - $num1{$first};
					}else{
						$lowcase = $num2{$first};
					}
					if($num2{$first} > ($num1{","} + $num1{"."})){
						if($num2{$first} >1 and $lowcase >1){
							$hash1{$chr}{$pos} = "$ref:$first";
						}elsif($num1{","}>1 and $num1{"."}>1){
							$hash1{$chr}{$pos} = "$ref:$ref";
						}else{
							$hash1{$chr}{$pos} = "$ref:$first";
						}
					}else{
						if($num1{","}>1 and $num1{"."}>1){
							$hash1{$chr}{$pos} = "$ref:$ref";
						}elsif($num2{$first} >1 and $lowcase >1){
							$hash1{$chr}{$pos} = "$ref:$first";
						}else{
							$hash1{$chr}{$pos} = "$ref:$ref";
						}
					}
				}
			}
		}
	}
	close PILEUP;

	foreach my $chr (keys %{$region{$key}}){			
		foreach my $beg(sort {$a<=>$b} keys %{$region{$key}{$chr}}){
			my $end =$region{$key}{$chr}{$beg};
			my ($c2, $c3, $c4);
			my $first_marker_pos;
			my $last_pos = 0;
			foreach my $pos (sort {$a<=>$b} keys %{$var{$chr}}){
				my $skip = 0;
				if ($pos >= $beg and $pos <= $end){
					if (exists $hash1{$chr}{$pos}){
						my $mut = (split /:/, $var{$chr}{$pos})[-1];				
						my $alle = (split /:/, $hash1{$chr}{$pos})[-1];
						my $ref =  (split /:/, $hash1{$chr}{$pos})[0];

						if ((length $mut) >1){
							my $dis = $pos - $last_pos;
							next if $dis <100;
							$mut = "R";
							if ($alle eq $ref){
								$alle = "A";
							}else{
								$alle = "G";
							}
						}else{
							if ($alle ne $ref){
								if ($jianbing{"$alle,$ref"}){
									$skip = 1 if $jianbing{"$alle,$ref"} ne $mut; #hete snp, but no matched
								}else{
									$skip = 1; #indel
								}					
							}
						}
				
						next if $skip == 1;
						$last_pos = $pos;

						if($c2){
							$c2 .= ",$pos";
							$c3 .= ",$mut";
							$c4 .= ",$alle:1";
						}else{
							$first_marker_pos = $pos;
							$c2 = "$pos";
							$c3 = "$mut";
							$c4 = "$alle:1";
						}
					}
				}elsif($pos > $end){
					last;
				}
			}
			if($first_marker_pos){
				my $len = $end - $beg +1;
				$out{$chr}{$first_marker_pos} .= "$chr\t$c2\t$c3\t$c4\t$key:1-$len#$chr-$beg-$end\n";
			}else{
				next;
			}
		}
	}
}

foreach my $chr (keys %out){
	foreach my $first (sort {$a<=>$b} keys %{$out{$chr}}){
		print $out{$chr}{$first};
	}
}
