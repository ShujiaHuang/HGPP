# Author : Shujia Huang
# Date   : 2012-07-25
#!/usr/bin/perl
use strict;
use warnings;

die "perl $0 Find_Fosmid_Program FileList MappingQuality outdir\n" 
	if ( @ARGV != 4 );
my ( $findFosmid, $fileList, $mapQ, $outdir ) = @ARGV;

system ("mkdir -p $outdir") if ( ! -d $outdir );

my %duplicate;
my $num = 0;
open I, $fileList or die "Cannot open file: $fileList\n";
while ( <I> ) {
#../input/bam/YHCDTMB-2DDABPEI/YHCDTMB-2DDABPEI_Index100.bam
	chomp;
	my @tmp = split /[\.\/]/;
	pop @tmp;

	my $subdir     ="$outdir/".(split /\_/, $tmp[-1])[0];
	my $outFilePre = $tmp[-1];
	die "File name duplicate!!\n$outFilePre\n" if ( defined $duplicate{ $outFilePre } );
	$duplicate{ $outFilePre } = 1;
	system ("mkdir -p $subdir") if ( ! -d $subdir );

	++$num;
	## output shell
	print "time $findFosmid -i $_ -p $outFilePre -l 1000 -q $mapQ -o $subdir/$outFilePre.fosmid > $subdir/$outFilePre.delete && rm -f $subdir/$outFilePre.fosmid && echo \"$outFilePre.fosmid Done\"\n";
}
close ( $fileList );

print STDERR "All $num shell\n";
