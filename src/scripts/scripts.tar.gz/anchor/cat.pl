#!/usr/bin/perl
use strict;
use warnings;

my ($fileList) = @ARGV;

my @files;
open I, $fileList or die "Cannot open file: $fileList\n";
while ( <I> ) { chomp; push( @files, $_ ); }
close ( I );

my $num   = 0;
for ( my $i = 0; $i < @files; ++$i ) {

	open I, $files[$i] or die "Cannot open file : $files[$i]\n";
	my @tmp;
	my $flag = 0;
	while ( <I> ) {
		chomp;
		next if ( $_ =~ m/^#/ || $_ =~ /^\s+$/ );
		$flag    = 1;
		@tmp     = split;
		die "ERROR: $files[$i]\t$num\n" if ( $tmp[0] !~ /^\d+/ || $num !~ /^\d+/ );
		$tmp[0] += $num;
		print join "\t", @tmp; print "\n";
	}

	$num = $tmp[0] if ( $flag );
	close(I);
}
