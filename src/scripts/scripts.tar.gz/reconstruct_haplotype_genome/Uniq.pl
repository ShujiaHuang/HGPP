#!/usr/bin/perl -w
use strict;

unless(@ARGV==1)
{
	print "perl $0 in.file\n";
	exit;
}

my %record;

open IN,"$ARGV[0]" or die "$!";
while(<IN>)
{
	next if(/^#/);
	my $PE1 = $_;
	my $PE11 = $PE1;
	my ($PR1) = split /\s+/,$PE1;
	$PE1=~s/^$PR1//;
	my $PE2 = <IN>;
	my $PE3 = <IN>;
	my $PE4 = <IN>;
	my $KEY = $PE11 . $PE2 . $PE3 . $PE4;
	$record{$PE1} = $KEY;
}
close IN;


foreach my $key(sort keys %record)
{
	print "$record{$key}";
}
