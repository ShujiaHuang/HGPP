#! /usr/bin/perl
use strict;
use FindBin qw($Bin $Script);
use lib "$Bin";

my $ref = $ARGV[0];
my $fq1 = $ARGV[1];
my $fq2 = $ARGV[2];
my $outDir = $ARGV[3];
mkdir $outDir unless -d $outDir;

my $basename = (split /\//, $fq1)[-1];
$basename =~ /(.+)\.pe1\.fq/;
my $prefix = $1;

$prefix = "$outDir/$prefix";

#====== Alignment ================
my $bwa = "$Bin/bwa";
print "$bwa index $ref","\n"; 
print "$bwa aln -o 1 -e 63 -i 15 -L -k 2 -l 31 -t 2 -q 10 $ref $fq1 >$prefix.1.sai\n";
print "$bwa aln -o 1 -e 63 -i 15 -L -k 2 -l 31 -t 2 -q 10 $ref $fq2 >$prefix.2.sai\n";
print "$bwa sampe -r '\@RG\\tID:L1\\tSM:YH_fosmid' $ref $prefix.1.sai $prefix.2.sai $fq1 $fq2 >$prefix.sam\n";  #note: -r

 #====== Deal SAM/BAM ================
my $samtools = "$Bin/samtools";
print "$samtools faidx $ref\n";
print "$samtools view -ubSt $ref.fai $prefix.sam > $prefix.raw.bam\n";
print "$samtools sort $prefix.raw.bam $prefix.bam.sort\n";
print "$samtools rmdup $prefix.bam.sort.bam $prefix.bam\n";
print "$samtools index $prefix.bam\n";

#===== call raw variant =========
my $bcftools = "$Bin/bcftools";
my $vcfutils  = "$Bin/vcfutils.pl";

print "$samtools mpileup -ugf $ref $prefix.bam | $bcftools view -bvcg - > $prefix.var.raw.bcf\n";
print "$bcftools view $prefix.var.raw.bcf | $vcfutils varFilter -D 300  > $prefix.var.flt.vcf\n";

#===== reAlignment By GATK ======
my $CreateSequenceDictionary = "$Bin/CreateSequenceDictionary.jar";
my $GenomeAnalysisTK = "$Bin/GenomeAnalysisTK.jar";

die "$ref must end up with '.fa'!\n" unless $ref =~ /(.+)\.fa$/;
$ref =~ /(.+)\.fa$/;
my $dict = "$1.dict";
print "rm $dict $prefix.realigned.bam\n"; #important
print "java -jar $CreateSequenceDictionary R=$ref O=$dict\n";
print "java -Xmx1g -jar $GenomeAnalysisTK -T RealignerTargetCreator -R $ref -o $prefix.gatk.intervals -known $prefix.var.flt.vcf\n";
print "java -Xmx1g -jar $GenomeAnalysisTK -T IndelRealigner -I $prefix.bam -R $ref -targetIntervals $prefix.gatk.intervals -o $prefix.realigned.bam -known $prefix.var.flt.vcf --consensusDeterminationModel KNOWNS_ONLY\n";

#==== call final variant =======
print "$samtools mpileup -ugf $ref $prefix.realigned.bam | $bcftools view -bvcg - > $prefix.realigned.var.raw.bcf\n";
print "$bcftools view $prefix.realigned.var.raw.bcf | $vcfutils varFilter -D 300  > $prefix.realigned.var.flt.vcf\n";

#==== construct correlated sequence ============
my $getCnsFromVCF = "$Bin/getCnsFromVCF.pl";
print "perl $getCnsFromVCF $prefix.realigned.var.flt.vcf $ref $prefix\n";

#==== delete some useless files ====
print "rm $prefix.*.sai $prefix.sam $prefix.raw.bam $prefix.bam.sort.bam  $prefix.*.raw.bcf\n";
