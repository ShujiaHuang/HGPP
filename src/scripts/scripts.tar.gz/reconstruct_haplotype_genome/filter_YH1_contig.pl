#! /usr/bin/perl
use strict;

my %hash;
my %cov;
my %mapped;

open IN, $ARGV[0] or die $!;
while(<IN>){
	chomp;
	next if /^#/;
	next unless /^\d/;
	my @tmp = split /\s+/, $_;
	my ($ref, $beg_t, $end_t) = @tmp[1,2,3];
	my ($ctg, $beg, $end) = @tmp[4,5,6];
	my $ori = $tmp[7];

	$hash{$ctg}{"$beg:$end"} = "$ref:$beg_t:$end_t:$ori";
=head
	if (exists $mapped{$ctg}{$beg}){
		$mapped{$ctg}{$beg} = $end if $mapped{$ctg}{$beg} < $end;
	}else{
		$mapped{$ctg}{$beg} = $end;
	}
=cut	
	
}
close IN;

my %len;
open STAT, $ARGV[1] or die $!;
while(<STAT>){
	chomp;
	my @tmp = split;
	$len{$tmp[0]} = $tmp[1];
}
close STAT;

=head
foreach my $ctg(keys %mapped){
	my $mapped_len = 0;
	my $last_end = 0;
	foreach my $beg(sort {$a<=>$b} keys %{$mapped{$ctg}}){
		$end = $mapped{$ctg}{$beg};
		if ($beg >= $last_end){
			$mapped_len += $end - $beg +1;
			$last_end = $end;
		}elsif($beg < $last_end and $end > $last_end){
			$mapped_len += $end - $last_end;
			$last_end = $end;
		}elsif($end <= $last_end){
			next;
		}
	}
}
=cut

my %region;
my %subopt;
foreach my $ctg(keys %hash){
	my $smallest;
	my $largest;
	my ($b1,$b2,$s1,$s2);
	foreach my $block (keys %{$hash{$ctg}}){
		$block =~ /(\d+):(\d+)/;
		my ($beg, $end) = ($1, $2);
		my $len = $end - $beg +1;
		unless (defined $smallest){
			$smallest = $beg;	
			$b1 = "$ctg:$block:$hash{$ctg}{$block}";
			$s1 = $len;
		}elsif(($beg < $smallest) or ($beg==$smallest and $s1 < $len)){
			$smallest = $beg;
			$b1 = "$ctg:$block:$hash{$ctg}{$block}";
			$s1 = $len;
		}

		unless (defined $largest){
			$largest = $end;
			$b2 = "$ctg:$block:$hash{$ctg}{$block}";
			$s2 = $len;
		}elsif(($end > $largest) or ($end == $largest and $s2 < $len)){
			$largest = $end;
			$b2 = "$ctg:$block:$hash{$ctg}{$block}";
			$s2 = $len;
		}
	}
	
	if ($s1<300 or $s2 <300){
		next;
	}else{
		my ($ctg, $beg_q_1, $end_q_1, $ref_1, $beg_t_1, $end_t_1, $ori_1) = (split /:/, $b1);
		my ($ctg, $beg_q_2, $end_q_2, $ref_2, $beg_t_2, $end_t_2, $ori_2) = (split /:/, $b2);
		next if $ref_1 ne $ref_2; #the same target
		my $ref = $ref_1;
		next if $ori_1 ne $ori_2; # the same orientation
		my $ori = $ori_1;
		
		my ($rev_beg, $rev_end); #reversed position
		$rev_beg = $len{$ctg} - $end_q_2 +1;
		$rev_end = $len{$ctg} - $beg_q_1 +1;

		if (abs($beg_t_2 - $end_t_1) > abs($beg_q_2 - $end_q_1) + 5000){
			next;
		}
		if ($end_t_1 > $end_t_2){
			next;
		}
		if ($beg_q_1 > 200 or $len{$ctg} - $end_q_2 > 200){
			$subopt{$beg_t_1}{$end_t_2} = "$ctg\t$beg_q_1\t$end_q_2\t$ori" if $ori eq "+";
			$subopt{$beg_t_1}{$end_t_2} = "$ctg\t$rev_beg\t$rev_end\t$ori" if $ori eq "-";
			next;
		}

		
		if ($ori eq "+"){
			$region{$beg_t_1}{$end_t_2} = "$ctg\t$beg_q_1\t$end_q_2\t$ori";
		}elsif($ori eq "-"){
			$region{$beg_t_1}{$end_t_2} = "$ctg\t$rev_beg\t$rev_end\t$ori";
		}
	}	
}



my %filt_reg;
my %gap;
my $last_end = 0;
foreach my $beg (sort {$a<=>$b} keys %region){
	foreach my $end (sort {$a<=>$b} keys %{$region{$beg}}){
		if($end <= $last_end){
			next;
		}elsif($beg > $last_end){
			my $tmp_beg = $last_end +1;
			my $tmp_end = $beg-1;
			$gap{$tmp_beg} = $tmp_end if $tmp_end >= $tmp_beg;
			$filt_reg{$beg}{$end} = "$region{$beg}{$end}\t$last_end";
			$last_end = $end;
		}else{
			$region{$beg}{$end} =~ /(.+)\t.+\t.+\t(.+)/;
			my $ctg = $1;
			my $ori = $2;
			foreach my $block (keys %{$hash{$ctg}}){
				$hash{$ctg}{$block} =~ /.+:(\d+):(\d+):(.+)/;
				if ($last_end >= $1 and $last_end <= $2 and $ori eq $3){
					$filt_reg{$beg}{$end} = "$region{$beg}{$end}\t$last_end";
					$last_end = $end;
					last;
				}
			}
		}
	}
}

foreach my $beg(sort {$a<=>$b} keys %gap){
	my $end= $gap{$beg};
	my $last_end = $beg -1;
	foreach my $beg_2(sort {$a<=>$b} keys %subopt){
		last if $beg_2 > $end;
		last if $last_end >= $end;
		foreach my $end_2(sort {$a<=>$b} keys %{$subopt{$beg_2}}){
			last if $last_end >= $end;
			if (($beg_2 <= $end and $beg_2 >= $beg) or ($end_2 <= $end and $end_2 >= $beg)){
				if($end_2 <= $last_end){
					next;
				}elsif($beg_2 >= $last_end){
					if ($end_2 <= $end){
						$filt_reg{$beg_2}{$end_2} = "$subopt{$beg_2}{$end_2}\t$last_end";
					}else{
						$filt_reg{$beg_2}{$end} = "$subopt{$beg_2}{$end_2}\t$last_end\tcut-$end"; # forced cut
					}
					$last_end = $end_2;
				}else{
					$subopt{$beg_2}{$end_2} =~ /(.+)\t.+\t.+\t(.+)/;
					my $ctg = $1;
					my $ori = $2;
					foreach my $block (keys %{$hash{$ctg}}){
						$hash{$ctg}{$block} =~ /.+:(\d+):(\d+):(.+)/;
						if ($last_end >= $1 and $last_end <= $2 and $ori eq $3){
							if ($end_2 <= $end){
								$filt_reg{$beg_2}{$end_2} = "$subopt{$beg_2}{$end_2}\t$last_end";
							}else{
								$filt_reg{$beg_2}{$end} = "$subopt{$beg_2}{$end_2}\t$last_end\tcut-$end"; # forced cut
							}
					        
							$last_end = $end_2;
					        last;
					    }
					}
				}
				delete $subopt{$beg_2}{$end_2};
			}
		}
	}
}

foreach my $beg(sort {$a<=>$b} keys %filt_reg){
	foreach my $end (sort {$a<=>$b} keys %{$filt_reg{$beg}}){
		print $beg,"\t",$end,"\t",$filt_reg{$beg}{$end},"\n";
	}
}
