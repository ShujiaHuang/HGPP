#! /usr/bin/perl -w
use strict;

my %ref;
$/ =">";
open FA, $ARGV[0] or die $!;
<FA>;
while(<FA>){
	chomp;
	my @id_and_seq = split /\n/, $_;
	my $id = (split /\s+/, $id_and_seq[0])[0];
	#$id = "chr$id"; different from the MHC region
	my $seq;
	for (my $i=1;$i<@id_and_seq;$i++){
		$seq .= "$id_and_seq[$i]";
	}
	$ref{$id} = $seq;
}
close FA;
$/ ="\n";


my $outDir = $ARGV[3];

my %hash;
open LIST, $ARGV[1] or die $!;
while(<LIST>){
	chomp;
	my $hap = (split /\s+/, $_)[0];
	$hash{$hap} =1;
}
close LIST;


open HAP, $ARGV[2] or die $!;
while(<HAP>){
	chomp;
	my @tmp = split;

	my $hap = $tmp[0];
	my $subDir = "$outDir/$hap";
	mkdir $subDir unless -d $subDir; # creat dir to store the query.fa and target.fa 

	my $sub_seq;
	if($hap =~ /(\w+)_\d+/){
		my $seq = $ref{$1};
		my ($beg, $end) = @tmp[1,2];
		$sub_seq = substr ($seq, $beg-1,$end-$beg+1);
	}else{
		die "$hap wrong when extracting the target seq!","\n";
	}
	if ($tmp[-1] ne "-" and exists $hash{$hap}){ # some haps may contain no contigs.
		open OUT, ">$subDir/$hap.target.fa" or die $!;
		print OUT ">$hap\n$sub_seq\n";
		close OUT;
	}else{
		open OUT, " >$subDir/cor.fa" or die $!;
		print OUT ">$hap\n$sub_seq\n";
		close OUT;
		`fold $subDir/cor.fa >$subDir/cor.format.fa`;
	}
}
close HAP;
