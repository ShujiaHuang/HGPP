## Author Hongzhi Cao
## Data: Modified at 2012/04/06
## This program was write to remove reduandent lastz alignment result.
## Input file should sort according to the assemble contig's position.


#!/usr/bin/perl -w
use strict;

unless(@ARGV==1)
{
	print "perl $0 in.axt<axt alignment result should sort according to assemble contig's postion>\n";
	exit;
}
my %record;
my $B_ID="1";
open IN,"$ARGV[0]" or die "$!";
while(<IN>)
{
	chomp();
	next if(/^#/);
	my $id = $_;
	my ($AID,$AP1,$AP2) = (split /\s+/)[4,5,6];
	chomp(my $ref= <IN>);
	chomp(my $axt= <IN>);
	<IN>;
	if($AID ne $B_ID)
	{
		if($B_ID ne "1")
		{
			&check($B_ID);
			delete($record{$B_ID});
		}
		# Add positon on scaffold for sort
		push @{$record{$AID}},[$id,$ref,$axt,$AP1,$AP2];
	}
	else
	{
		push @{$record{$AID}},[$id,$ref,$axt,$AP1,$AP2];
	}
	$B_ID=$AID; 
}
close IN;
&check($B_ID);

sub check()
{
	my $id = shift;
	if(@{$record{$id}} == 1) ## Only on hit
	{
		print "$record{$id}[0][0]\n$record{$id}[0][1]\n$record{$id}[0][2]\n\n";
	}
	else
	{
		for(my $i=0;$i<@{$record{$id}}-1;$i++)
		{ 	
##			print "Here in the $i cycle\n"; ############
			my $ID1= $record{$id}[$i][0];
			my $ID2= $record{$id}[$i+1][0];
			my @field1 = split /\s+/,$ID1;
			my @field2 = split /\s+/,$ID2;
			if($field2[5] < $field1[6]) ## Have overlap
			{
##				print "Overlap $i with next\n"; ########
				my $OS = 0; ##next Lastz alignment result overlap size with last one.
				if($field2[6] < $field1[6]) ## contained by last Lastz alignment result
				{
					$OS=$field1[6]-$field2[6];
				}
				my $Overlap = $field1[6]-$field2[5]+1-$OS;
##				print "Overlap size is $Overlap, OS is $OS\n";############
				my @ref1 = split //,$record{$id}[$i][1];
				my @axt1 = split //,$record{$id}[$i][2];
				my @ref2 = split //,$record{$id}[$i+1][1];
				my @axt2 = split //,$record{$id}[$i+1][2];
				my ($Base1,$Base2)=("","");
				my ($Indel1,$Indel2,$Length1,$Length2,$Position1,$Position11,$Position2,$RefP1,$RefP2,$RefPP1,$MMM) = (0,0,0,0,0,0,0,0,0,0,0);
				### Part1's find back
				if($field1[7] eq "+") ##From back to front
				{
					for(my $n=@axt1-1;$n>=0 && $Length1<$Overlap;$n--)
					{
						if($MMM<$OS)
						{
							if($axt1[$n] ne "-")
							{
								$MMM++;
							}
							if($ref1[$n] ne "-")
							{
								$RefPP1++;
							}
							$Position11++;
						}
						else
						{
							if($axt1[$n] ne "-")
							{
								$Length1++;
								$Base1 .= $axt1[$n];
							}
							else
							{
								$Indel1++;	
							}
							if($ref1[$n] eq "-")
							{
								$Indel1++;
							}
							else
							{
								$RefP1++;
							}
							if(uc $axt1[$n] ne uc $ref1[$n] && $axt1[$n] ne "-" && $ref1[$n] ne "-" && $axt1[$n] ne "N" && $ref1[$n] ne "N")
							{
								$Indel1+=0.2;
							}
						}
						$Position1++;
					}
					$Base1 = reverse $Base1;
				}
				else ## scaffold align to the reverse strand
				{
					for(my $n=0;$n<@axt1 && $Length1 < $Overlap;$n++)
					{
						if($MMM<$OS)
						{
							if($axt1[$n] ne "-")
							{
								$MMM++;
							}
							if($ref1[$n] ne "-")
							{
								$RefPP1++;
							}
							$Position11++;
						}
						else
						{
							if($axt1[$n] ne "-")
							{
								$Length1++;
								$Base1 .= $axt1[$n];
							}
							else
							{
								$Indel1++;	
							}
							if($ref1[$n] eq "-")
							{
								$Indel1++;
							}
							else
							{
								$RefP1++;
							}
							if(uc $axt1[$n] ne uc $ref1[$n] && $axt1[$n] ne "-" && $ref1[$n] ne "-" && $axt1[$n] ne "N" && $ref1[$n] ne "N")
							{
								$Indel1+=0.2;
							}
						}
						$Position1++;
					}
				}
				## Part2's find back
				if($field2[7] eq "-") ##From back to front
				{
					for(my $n=@axt2-1;$n>=0 && $Length2<$Overlap;$n--)
					{
						if($axt2[$n] ne "-")
						{
							$Length2++;
							$Base2 .= $axt2[$n];
						}
						else
						{
							$Indel2++;	
						}
						if($ref2[$n] eq "-")
						{
							$Indel2++;
						}
						else
						{
							$RefP2++;
						}
						if(uc $axt2[$n] ne uc $ref2[$n] && $axt2[$n] ne "-" && $ref2[$n] ne "-" && $axt2[$n] ne "N" && $ref2[$n] ne "N")
						{
							$Indel2+=0.2;
						}
						$Position2++;
					}
					$Base2 = reverse $Base2;
				}
				else
				{
					for(my $n=0;$n<@axt2 && $Length2 < $Overlap;$n++)
					{
						if($axt2[$n] ne "-")
						{
							$Length2++;
							$Base2 .= $axt2[$n];
						}
						else
						{
							$Indel2++;	
						}
						if($ref2[$n] eq "-")
						{
							$Indel2++;
						}
						else
						{
							$RefP2++;
						}
						if(uc $axt2[$n] ne uc $ref2[$n] && $axt2[$n] ne "-" && $ref2[$n] ne "-" && $axt2[$n] ne "N" && $ref2[$n] ne "N")
						{
							$Indel2+=0.2;
						}
						$Position2++;
					}
				}
				### Judge
				$Base1 = uc $Base1;
				$Base2 = uc $Base2;
				my $RVBase1 = $Base1;
				$RVBase1 =~tr/[ATCGN]/[TAGCN]/;
				$RVBase1 = reverse $RVBase1;
##				print "length $Length1\t$Length2\n";
##				print "sequence\n$Base1\n$Base2\n";
				if($Base1 eq $Base2 || $RVBase1 eq $Base2)
				{
##					print "Mark $Indel2\t$Indel1\n";
##					print "Equal\n$Base1\n$Base2\n";
					if($Indel2 >= $Indel1) ## which means keep the first part
					{
##						print "Keep first\n";
						if($OS==0 && $field2[6] - $field2[5]-$Overlap >= 100 ) ## Two alignment have overlap but do not fully contained. keep other alignment result if length large than 100bp.
						{
##							print "Second remain part large 100bp\n";
							if($field2[7] eq "+")
							{
								$field2[2]+=$RefP2;
								$field2[5]+=$Overlap;
								$record{$id}[$i+1][0]= join " ",@field2;
								$record{$id}[$i+1][1]= substr($record{$id}[$i+1][1],$Position2);
								$record{$id}[$i+1][2]= substr($record{$id}[$i+1][2],$Position2);
								$record{$id}[$i+1][3]+=$Overlap;
							}
							else
							{
								$field2[3]-=$RefP2;
								$field2[5]+=$Overlap;
								$record{$id}[$i+1][0]= join " ",@field2;
								$record{$id}[$i+1][1]= substr($record{$id}[$i+1][1],0,length($record{$id}[$i+1][1])-$Position2);
								$record{$id}[$i+1][2]= substr($record{$id}[$i+1][2],0,length($record{$id}[$i+1][2])-$Position2);
								$record{$id}[$i+1][3]+=$Overlap;
							}
						}
						else ## Delete the second part's alignment result
						{
##							print "Second remain less than 100bp\n";
							my @Temp;
							for(my $N=0;$N<=$i;$N++)
							{
								$Temp[$N][0] = $record{$id}[$N][0];
								$Temp[$N][1] = $record{$id}[$N][1];
								$Temp[$N][2] = $record{$id}[$N][2];
								$Temp[$N][3] = $record{$id}[$N][3];
								$Temp[$N][4] = $record{$id}[$N][4];
							}
							for(my $N=$i+2;$N<@{$record{$id}};$N++)
							{
								$Temp[$N-1][0] = $record{$id}[$N][0];
								$Temp[$N-1][1] = $record{$id}[$N][1];
								$Temp[$N-1][2] = $record{$id}[$N][2];
								$Temp[$N-1][3] = $record{$id}[$N][3];
								$Temp[$N-1][4] = $record{$id}[$N][4];
							}
							@{$record{$id}} = @Temp;
						}
					}
					else ## which means keep the second alignment. So, we should carefully think about what should be keeped.
					{
##						print "Keep the second result\n";
						if($OS==0) ## which means do not be contained, only keep alignment large than 100bp
						{
							if($field1[6]-$field1[5]-$Overlap>=100) ## Keep the first alignment
							{
								if($field1[7] eq "-")
								{
									$field1[2]+=$RefP1;
									$field1[6]-=$Overlap;
									$record{$id}[$i][0]= join " ",@field1;
									$record{$id}[$i][1]= substr($record{$id}[$i][1],$Position1);
									$record{$id}[$i][2]= substr($record{$id}[$i][2],$Position1);
									$record{$id}[$i][4]-=$Overlap;
								}
								else
								{
									$field1[3]-=$RefP1;
									$field1[6]-=$Overlap;
									$record{$id}[$i][0]= join " ",@field1;
									$record{$id}[$i][1]= substr($record{$id}[$i][1],0,length($record{$id}[$i][1])-$Position1);
									$record{$id}[$i][2]= substr($record{$id}[$i][2],0,length($record{$id}[$i][2])-$Position1);
									$record{$id}[$i][4]-=$Overlap;
								}
							}
							else ## Delete the first one
							{
								my @Temp;
								for(my $N=0;$N<$i;$N++)
								{
									$Temp[$N][0] = $record{$id}[$N][0];
									$Temp[$N][1] = $record{$id}[$N][1];
									$Temp[$N][2] = $record{$id}[$N][2];
									$Temp[$N][3] = $record{$id}[$N][3];
									$Temp[$N][4] = $record{$id}[$N][4];
								}
								for(my $N=$i+1;$N<@{$record{$id}};$N++)
								{
									$Temp[$N-1][0] = $record{$id}[$N][0];
									$Temp[$N-1][1] = $record{$id}[$N][1];
									$Temp[$N-1][2] = $record{$id}[$N][2];
									$Temp[$N-1][3] = $record{$id}[$N][3];
									$Temp[$N-1][4] = $record{$id}[$N][4];
								}
								@{$record{$id}} = @Temp;
							}
						}
						else ## the Second alignment was contained 
						{
##							print "Here contained ,and OS large than 100";
							if($field1[6]-$field1[5]-$Overlap-$OS >= 100 && $OS<100) ## Keep the First part
							{
								if($field1[7] eq "-")
								{
									$field1[2]+=$RefP1+$RefPP1;
									$field1[6]-=$Overlap+$OS;
									$record{$id}[$i][0]= join " ",@field1;
									$record{$id}[$i][1]= substr($record{$id}[$i][1],$Position1);
									$record{$id}[$i][2]= substr($record{$id}[$i][2],$Position1);
									$record{$id}[$i][4]-=$Overlap+$OS;
								}
								else
								{
									$field1[3]-=$RefP1+$RefPP1;
									$field1[6]-=$Overlap+$OS;
									$record{$id}[$i][0]= join " ",@field1;
									$record{$id}[$i][1]= substr($record{$id}[$i][1],0,length($record{$id}[$i][1])-$Position1);
									$record{$id}[$i][2]= substr($record{$id}[$i][2],0,length($record{$id}[$i][2])-$Position1);
									$record{$id}[$i][4]-=$Overlap+$OS;
								}
							}
							elsif($OS>=100 && $field1[6]-$field1[5]-$Overlap-$OS <100) ## Keep the last part
							{
								if($field1[7] eq "-")
								{
									$field1[3]=$field1[2]+$RefPP1-1;
									$field1[5]=$field1[6]-$OS+1;## Here should more carefully.
									$record{$id}[$i][0] = join " ",@field1;
									$record{$id}[$i][1] = substr($record{$id}[$i][1],0,$Position11);
									$record{$id}[$i][2] = substr($record{$id}[$i][2],0,$Position11);
									$record{$id}[$i][3] = $field1[6] - $OS+1;
								}
								else
								{
									$field1[2]=$field1[3]-$RefPP1+1;
									$field1[5]=$field1[6]-$OS+1;## Here should more carefully.
									$record{$id}[$i][0] = join " ",@field1;
									$record{$id}[$i][1] = substr($record{$id}[$i][1],length($record{$id}[$i][1])-$Position11);
									$record{$id}[$i][2] = substr($record{$id}[$i][2],length($record{$id}[$i][2])-$Position11);
									$record{$id}[$i][3] = $field1[6] - $OS+1;
								}
							}
							elsif($OS>= 100 && $field1[6]-$field1[5]-$Overlap-$OS >= 100) ## Keep both of them
							{
#								print "Makr\t$field1[5]\t$field1[6]\t$field2[5]\t$field2[6]\t$Overlap\t$OS\tEnd\n";
								#### Keep the last alignment result
								my ($RL,$RR,$AL,$AR) = ($field1[2],$field1[3],$field1[5],$field1[6]);
								my $B = @{$record{$id}};
								if($field1[7] eq "-")
								{
									$field1[3]=$field1[2]+$RefPP1-1;
									$field1[5]=$field1[6]-$OS+1;## Here should more carefully.
									$record{$id}[$B][0] = join " ",@field1;
									$record{$id}[$B][1] = substr($record{$id}[$i][1],0,$Position11);
									$record{$id}[$B][2] = substr($record{$id}[$i][2],0,$Position11);
									$record{$id}[$B][3] = $field1[6] - $OS +1;
									$record{$id}[$B][4] = $field1[6];
								}
								else
								{
									$field1[2]=$field1[3]-$RefPP1+1;
									$field1[5]=$field1[6]-$OS+1;## Here should more carefully.
									$record{$id}[$B][0] = join " ",@field1;
									$record{$id}[$B][1] = substr($record{$id}[$i][1],length($record{$id}[$i][1])-$Position11);
									$record{$id}[$B][2] = substr($record{$id}[$i][2],length($record{$id}[$i][2])-$Position11);
									$record{$id}[$B][3] = $field1[6] - $OS+1;
									$record{$id}[$B][4] = $field1[6];
								}
								#### Keep the first alignment result
								if($field1[7] eq "-")
								{
									$field1[2] = $RL;
									$field1[3] = $RR;
									$field1[5] = $AL;
									$field1[6] = $AR;
									$field1[2]+=$RefP1+$RefPP1;
									$field1[6]-=$Overlap+$OS;
									$record{$id}[$i][0]= join " ",@field1;
									$record{$id}[$i][1]= substr($record{$id}[$i][1],$Position1);
									$record{$id}[$i][2]= substr($record{$id}[$i][2],$Position1);
									$record{$id}[$i][4]-=$Overlap+$OS;
								}
								else
								{
									$field1[2] = $RL;
									$field1[3] = $RR;
									$field1[5] = $AL;
									$field1[6] = $AR;
									$field1[3]-=$RefP1+$RefPP1;
									$field1[6]-=$Overlap+$OS;
									$record{$id}[$i][0]= join " ",@field1;
									$record{$id}[$i][1]= substr($record{$id}[$i][1],0,length($record{$id}[$i][1])-$Position1);
									$record{$id}[$i][2]= substr($record{$id}[$i][2],0,length($record{$id}[$i][2])-$Position1);
									$record{$id}[$i][4]-=$Overlap+$OS;
								}
#		print "Make New one $B\t$record{$id}[$B][3]\t$record{$id}[$B][4]\n$record{$id}[$B][1]\n$record{$id}[$B][2]\n";
							}
							else ## Delete the first one them all
							{
								my @Temp;
								for(my $N=0;$N<$i;$N++)
								{
									$Temp[$N][0] = $record{$id}[$N][0];
									$Temp[$N][1] = $record{$id}[$N][1];
									$Temp[$N][2] = $record{$id}[$N][2];
									$Temp[$N][3] = $record{$id}[$N][3];
									$Temp[$N][4] = $record{$id}[$N][4];
								}
								for(my $N=$i+1;$N<@{$record{$id}};$N++)
								{
									$Temp[$N-1][0] = $record{$id}[$N][0];
									$Temp[$N-1][1] = $record{$id}[$N][1];
									$Temp[$N-1][2] = $record{$id}[$N][2];
									$Temp[$N-1][3] = $record{$id}[$N][3];
									$Temp[$N-1][4] = $record{$id}[$N][4];
								}
								@{$record{$id}} = @Temp;
							}
						}
					}
					########### resort the alignment result and redo remove redandent.
					@{$record{$id}} = sort{my $da =$a->[3]; my $db = $b->[3] ;if($a->[3] == $b->[3]){ $da =$a->[4]; $db = $b->[4]; } $da <=> $db;} @{$record{$id}};
					$i =-1;
					###########
				}
				else
				{
					print "Wrong\n$Base1\n$Base2\n$record{$id}[$i][0]\n$record{$id}[$i+1][0]\n";
				}
			}
		#############
#	else
#			{
#				if($i != @{$record{$id}}-2)
#				{
#					print "$record{$id}[$i][0]\n$record{$id}[$i][1]\n$record{$id}[$i][2]\n\n";
#				}
#				else
#				{
#					print "$record{$id}[$i][0]\n$record{$id}[$i][1]\n$record{$id}[$i][2]\n\n";
#					print "$record{$id}[$i+1][0]\n$record{$id}[$i+1][1]\n$record{$id}[$i+1][2]\n\n";
#				}
#			}
		}
		### Here output all Lastz alignment result.
		for(my $i=0;$i<@{$record{$id}};$i++)
		{
			print "$record{$id}[$i][0]\n$record{$id}[$i][1]\n$record{$id}[$i][2]\n\n";
		}
	}
}



