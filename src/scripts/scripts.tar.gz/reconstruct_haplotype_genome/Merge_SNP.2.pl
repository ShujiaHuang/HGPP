#!/usr/bin/perl -w
use strict;

unless(@ARGV==1)
{
	print "perl $0 in.snp\n";
	exit;
}
my %SNP;
open IN,"$ARGV[0]" or die "$!";
while(<IN>)
{
	chomp();
	my @field = split /\s+/;
	my $key = $field[1] . "\t" . $field[2] . "\t" . $field[3];
	my $Block = $field[6] . "|" . $field[7] . "|" . $field[8] . "|" . $field[9] . "|" . $field[0];
	if(!exists $SNP{$key})
	{
		$SNP{$key}[0]=1;
		$SNP{$key}[1]=uc $field[6];
		$SNP{$key}[2]=$Block;
		$SNP{$key}[3]= $field[5];
	}
	else
	{
		$SNP{$key}[0]++;
		my $Base = uc $field[6];
		if($SNP{$key}[1] !~/$Base/)
		{
			$SNP{$key}[1] .= $Base;
		}
		$SNP{$key}[2] .= "/" . $Block;
		if($field[5]=~/[atcg]/)
		{
			$SNP{$key}[3] = $field[5];
		}
	}

}
close IN;
foreach my $key(sort keys %SNP)
{
	print "$key\t$SNP{$key}[3]";
	my $len = length($SNP{$key}[1]);
	print "\t$SNP{$key}[0]\t$len\t$SNP{$key}[1]\t$SNP{$key}[2]\n";
}
