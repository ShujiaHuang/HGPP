#! /usr/bin/perl
use strict;

open BED, $ARGV[0] or die $!;
my %hash;
while(<BED>){
	chomp;
	my @tmp = split;
	my ($beg, $end, $ctg, $ctg_beg, $ctg_end , $ori) = @tmp[0,1,2,3,4,5];
	$hash{$ctg} = "$beg:$end:$ctg_beg:$ctg_end:$ori";
}
close BED;

$/ = ">";
open FA, $ARGV[1] or die $!;
<FA>;
while(<FA>){
	chomp;
#$_ =~ s/\n//g;
#$_ =~ /(.+\d+)(.+)/;
#	my $ctg = (split /\s+/,$1)[0];
#	my $seq = $2;
	my @ctg_and_seq = split /\n+/, $_;
	my $ctg = (split /\s+/, $ctg_and_seq[0])[0];
	my $seq;
	for (my $i=1;$i<@ctg_and_seq;$i++){
	    $seq .= "$ctg_and_seq[$i]";
	}
	next unless $hash{$ctg};
	my ($beg, $end, $ctg_beg, $ctg_end, $ori) = split /:/, $hash{$ctg};
	my $len = $ctg_end - $ctg_beg +1;
	my $sub_seq = substr($seq, $ctg_beg-1, $len);
	if ($ori eq "-"){
		$sub_seq = reverse $sub_seq;
		$sub_seq =~ tr/ACGTacgt/TGCAtgca/;
	}
	$sub_seq =~ tr/atgcn/ATGCN/; #use capital letters to represent the bases from YH1 contigs.
	print "$beg\t$end\t$ctg\t$sub_seq\n";
}
close FA;
