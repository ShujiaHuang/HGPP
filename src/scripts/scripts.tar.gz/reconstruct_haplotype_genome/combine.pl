#! /usr/bin/perl -w
use strict;

my $seq;
open IN, $ARGV[0] or die $!;
while(<IN>){
	chomp;
	$seq .= (split /\s+/, $_)[3];
}
close IN;

my $prefix = $ARGV[1];
print ">$prefix\n",$seq,"\n";
