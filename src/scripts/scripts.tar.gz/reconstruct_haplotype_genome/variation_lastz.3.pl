#!/usr/bin/perl -w
use strict;

unless(@ARGV==1)
{
	print "perl $0 in.axt\n";
	exit;
}

open IN,"$ARGV[0]" or die "$!";
while(<IN>)
{
	chomp();
	my $LINE1 = $_;
	chomp(my $LINE2=<IN>);
	chomp(my $LINE3=<IN>);
	<IN>;
	my @line1 = split /\s+/,$LINE1;
	my @line2 = split //,$LINE2;
	my @line3 = split //,$LINE3;
	my $RS = $line1[2];
	my $step = 0;
	my $NR = 0;
	my @variation; ## Start,End,kind(-1,0,1,2),ref,base
	## Here -1 for N , both start and end including N region
	## Here 0 for snp 1 for insertion 2 for deletion
	## SNP start eq end eq SNP postion
	## Insertion start eq end eq insertion site which insertion happend at the back of this site
	## Deletion start ne end ,start eq Deletion start site, end equal the end +1 of deletion which not include in the deletion
	for(my $i=0;$i<@line2;$i++)
	{
		if($line2[$i] ne "-" && $line3[$i] ne "-") ## Not indel place
		{
			if(uc $line2[$i] ne uc $line3[$i] && $line3[$i] ne "N") ## mismatch place
			{
				push @variation,[$RS+$step,$RS+$step,0,$line2[$i],$line3[$i]];
			}
			elsif($line3[$i] eq "N")
			{
				my $NS = $RS+$step;
				while($i+1 < @line2 && $line3[$i+1] eq "N" && $line2[$i+1] ne "-")
				{
					$step++;
					$i++;
				}
				my $NE = $RS+$step;
				push @variation,[$NS,$NE,-1,0,0];
				$NR++;
			}
		}
		elsif($line2[$i] eq "-") ## Insertion
		{
			$step--;
			my $Insertion .= $line3[$i];
			while($line2[$i+1] eq "-")
			{
				$Insertion .= $line3[$i+1];
				$i++
			}
			my $len = length($Insertion);
			push @variation,[$RS+$step,$RS+$step,1,$len,$Insertion];
			if($Insertion=~/N/) ## which means have N in the sequence
			{
				push @variation,[$RS+$step,$RS+$step,-1,0,0];
			}
		}
		elsif($line3[$i] eq "-") ## Deletion
		{
			my $Deletion .= $line2[$i];
			my $DS = $RS+$step;
			while($line3[$i+1] eq "-")
			{
				if($line2[$i+1] eq "-")
				{
					$step--;
				}
				else
				{
					$Deletion .= $line2[$i+1];
				}
				$i++;
				$step++;
			}
			my $DE = $RS+$step+1;
			my $len = length($Deletion);
			push @variation,[$DS,$DE,2,$len,$Deletion];
		}
		else
		{
			print "Impossible";
		}
		$step++;
	}
	if(@variation-$NR > 0) ## which means have variation
	{
		for(my $i=0;$i<@variation;$i++)
		{
			if($variation[$i][2] != -1) ## Not N, then should be SNP/indel/Deletion
			{
				my ($M,$V,$N) = &Near_variation($i,@variation);	
				print "$line1[4]\t$line1[1]\t$variation[$i][0]\t$variation[$i][1]\t$variation[$i][2]\t$variation[$i][3]\t$variation[$i][4]\t$M\t$V\t$N\n";
			}
		}
	}
}
close IN;

sub Near_variation()
{
	my ($N,@variation) = @_;
	my $L_N_D = 0;
	my $L_M_D = 0;
	my $L_V_D = 0;
	my $R_N_D = 0;
	my $R_M_D = 0;
	my $R_V_D = 0;
	my $N_Left = $variation[$N][0];
	my $N_right= $variation[$N][1];
##  serar left;
	for(my $i=$N-1;$i>=0;$i--)
	{
		if($variation[$i][2] == 0) ## snp
		{
			if($L_M_D == 0)
			{
				$L_M_D = $N_Left - $variation[$i][1];
				$L_M_D = 1 if($L_M_D <= 0);
			}
		}
		elsif($variation[$i][2] == -1) ## N
		{
			if($L_N_D == 0)
			{
				$L_N_D = $N_Left - $variation[$i][1];
				$L_N_D = 1 if($L_N_D <= 0);
			}
		}
		elsif($variation[$i][2] == 1 || $variation[$i][2] == 2) ## Indel
		{
			if($L_V_D == 0)
			{
				$L_V_D = $N_Left - $variation[$i][1];
				$L_V_D = 1 if($L_V_D <= 0);
			}
		}
		else
		{
			print "Wrong\n";
			exit;
		}
		if($L_V_D > 0 && $L_N_D >0)
		{
			last;
		}
	}
##  serar Right
	for(my $i=$N+1;$i<@variation;$i++)
	{
		if($variation[$i][2] == 0) ## snp
		{
			if($R_M_D == 0)
			{
				$R_M_D =$variation[$i][0] - $N_right;
				$R_M_D = 1 if($R_M_D <= 0);
			}
		}
		elsif($variation[$i][2] == -1) ## N
		{
			if($R_N_D == 0)
			{
				$R_N_D =$variation[$i][0] - $N_right;
				$R_N_D = 1 if($R_N_D <= 0);
			}
		}
		elsif($variation[$i][2] == 1 || $variation[$i][2] == 2) ## Indel
		{
			if($R_V_D == 0)
			{
				$R_V_D =$variation[$i][0] - $N_right;
				$R_V_D = 1 if($R_V_D <= 0);
			}
		}
		else
		{
			print "Wrong\n";
			exit;
		}
		if($R_V_D > 0 && $R_N_D > 0)
		{
			last;
		}
	}	
	my($M_D,$V_D,$N_D) = (0,0,0);
	## mismatch
	if($R_M_D ==0 && $L_M_D == 0)
	{
		$M_D = 0;
	}
	elsif($R_M_D==0)
	{
		$M_D = $L_M_D;
	}
	elsif($L_M_D==0)
	{
		$M_D = $R_M_D;
	}
	else
	{
		$M_D = $R_M_D <= $L_M_D ? $R_M_D : $L_M_D;
	}
	## Indel
	if($R_V_D ==0 && $L_V_D == 0)
	{
		$V_D = 0;
	}
	elsif($R_V_D==0)
	{
		$V_D = $L_V_D;
	}
	elsif($L_V_D==0)
	{
		$V_D = $R_V_D;
	}
	else
	{
		$V_D = $R_V_D <= $L_V_D ? $R_V_D : $L_V_D;
	}
	## N region
	if($R_N_D ==0 && $L_N_D == 0)
	{
		$N_D = 0;
	}
	elsif($R_N_D==0)
	{
		$N_D = $L_N_D;
	}
	elsif($L_N_D==0)
	{
		$N_D = $R_N_D;
	}
	else
	{
		$N_D = $R_N_D <= $L_N_D ? $R_N_D : $L_N_D;
	}

	return($M_D,$V_D,$N_D);
}


