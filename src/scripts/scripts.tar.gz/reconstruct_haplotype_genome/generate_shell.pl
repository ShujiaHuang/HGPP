#! /usr/bin/perl
use strict;
use FindBin qw($Bin $Script);
use lib "$Bin";

my @files = `find $ARGV[0] -name '*.target.fa'`;
chomp @files;

my $lastz = "$Bin/lastz";
my $msort = "$Bin/msort";
my $fa_stat = "$Bin/fa_stat.pl";
foreach my $file (@files){
	$file =~ /(.+)\/.+/;
	my $subDir = $1;
	my $hap_id = (split /\//,$subDir)[-1];
	my $query = "$subDir/$hap_id.query.fa";

	`perl $fa_stat $file >$file.len`;
	`perl $fa_stat $query > $query.len`;

	my $axt = "$subDir/$hap_id.axt";
	my $axt_self = "$subDir/YH1_mapped_to_new_hap.axt";
	
#	print "export LD_LIBRARY_PATH=\"/panfs/CD/zhangfan/lib/zlib-1.2.5/:/opt/gridengine/lib/lx26-amd64:/panfs/CD/linhx/bin/yanhuang/pezmaster31-bamtools-12aca98/lib:/opt/blc/gcc-4.5.0/lib64:/panfs/CD/zhangfan/lib/lib/:/panfs/CD/linhx/bin/boost/boost_1_47_0/stage/lib:\$LD_LIBRARY_PATH:/opt/gridengine/lib/lx26-amd64:/opt/gridengine/lib/lx26-amd64:/usr/lib/oracle/11.1.0.1/client64/lib:/share/raid1/genome/biosoft/glibc-2.11/glibc-2.11/:/panfs/CD/zhangfan/lib/:/panfs/CD/zhangfan/lib/BioPerl-1.6.1/\"\n";
	print "$lastz $file $query --strand=both --hspthresh=10000 --chain --ambiguous=iupac --gapped --ydrop=50000 --gap=2000,1 --identity=90 --step=19 --word=31 --seed=12of19 --format=axt --output=$axt --markend\n";
	print "perl $Bin/Uniq.pl $axt >$axt.uniq\n";
	print "$Bin/trans_pos.pl $query.len $axt.uniq >$axt.uniq.tp\n";
	print "$msort -L4 -km5,n6,rn7,km2,n3,n4 $axt.uniq.tp >$axt.uniq.tp.ms\n";
	print "perl $Bin/filter_axt.5.pl $axt.uniq.tp.ms >$axt.uniq.tp.ms.fildup\n";
	print "perl $Bin/trans_pos.pl $query.len $axt.uniq.tp.ms.fildup >$axt.uniq.tp.ms.fildup.tp\n";
#	print "$Bin/axt_correction $axt.uniq.tp.ms.fildup.tp >$axt.uniq.tp.ms.fildup.tp.cor\n";
	print "$Bin/axtSort $axt.uniq.tp.ms.fildup.tp $axt.uniq.tp.ms.fildup.tp.sort\n";
	print "$Bin/axtBest $axt.uniq.tp.ms.fildup.tp.sort all $axt.uniq.tp.ms.fildup.tp.sort.best\n";
#	my $bin = "/ifs5/ST_IM/PMO/SZY10003_YHfosmid/sunyuhui/V2_MHC/GetSeq_test/inhouse/";
	
	print "perl $Bin/filter_YH1_contig.pl $axt $query.len >$subDir/step01.locate\n";
	print "perl $Bin/link_YH1_contig_V2.pl $axt $query.len $subDir/step01.locate >$subDir/step02.media\n";
	print "perl $Bin/extract_seq.pl $subDir/step02.media $query |$msort -kn1,n2 >$subDir/step03.fa\n";
	print "perl $Bin/get_gap.pl $subDir/step03.fa $file >$subDir/step04.gap.list\n";
	print "perl $Bin/fill_seq.pl $subDir/step03.fa $subDir/step04.gap.list $axt.uniq.tp.ms.fildup.tp.sort.best $subDir/step05.clean.fa $subDir/step05.total.fa\n";
	print "cat $subDir/step03.fa $subDir/step05.total.fa |$msort  -kn1,n2 > $subDir/step06.fa\n";
	print "perl $Bin/get_gap.pl $subDir/step06.fa $file >$subDir/step07.gap.list\n";
	print "perl $Bin/extract_sub_ref.pl $subDir/step07.gap.list $file >$subDir/step08.sub_ref.fa\n";
	print "cat $subDir/step03.fa $subDir/step05.clean.fa $subDir/step08.sub_ref.fa |$msort -kn1,n2 >$subDir/hap.fa.media\n";
	print "perl $Bin/combine.pl $subDir/hap.fa.media $hap_id >$subDir/hap.fa\n";
	print "fold $subDir/hap.fa > $subDir/hap.format.fa\n";

	print "$lastz $subDir/hap.fa $query --strand=both --hspthresh=10000 --chain --ambiguous=iupac --gapped --ydrop=50000 --gap=2000,1 --identity=90 --step=19 --word=31 --seed=12of19 --format=axt --output=$axt_self --markend\n";
	print "perl $Bin/Uniq.pl $axt_self >$axt_self.uniq\n";
	print "$Bin/trans_pos.pl $query.len $axt_self.uniq >$axt_self.uniq.tp\n";
	print "$msort -L4 -km5,n6,rn7,km2,n3,n4 $axt_self.uniq.tp >$axt_self.uniq.tp.ms\n";
	print "perl $Bin/filter_axt.5.pl $axt_self.uniq.tp.ms >$axt_self.uniq.tp.ms.fildup\n";
	print "perl $Bin/trans_pos.pl $query.len $axt_self.uniq.tp.ms.fildup >$axt_self.uniq.tp.ms.fildup.tp\n";
	print "perl $Bin/variation_lastz.3.pl $axt_self.uniq.tp.ms.fildup.tp >$subDir/self.v\n";
	print "$msort -kn3,n4 $subDir/self.v |awk '\$5==\"0\"' >$subDir/self.v.sort.snp\n";
	print "$msort -kn3,n4 $subDir/self.v |awk '\$5>0' >$subDir/self.v.sort.indel\n";
	print "perl $Bin/Merge_SNP.2.pl $subDir/self.v.sort.snp >$subDir/self.v.sort.snp.merge\n";
	print "perl $Bin/make_pileup.2.pl $subDir/self.v.sort.snp.merge $axt_self.uniq.tp.ms.fildup.tp >$subDir/snp.pileup\n";
	print "perl $Bin/Merge_indel.pl $subDir/self.v.sort.indel >$subDir/self.v.sort.indel.merge\n";
	
	print "perl $Bin/make_pileup.indel.2.pl $subDir/self.v.sort.indel.merge $axt_self.uniq.tp.ms.fildup.tp > $subDir/indel.pileup\n";
	print "perl $Bin/getCnsFromPileup.pl $subDir/snp.pileup $subDir/indel.pileup $subDir/hap.format.fa $subDir/prefix >$subDir/cor.fa\n";
	print "fold $subDir/cor.fa > $subDir/cor.format.fa\n";
	print "rm $axt $axt.uniq.* $axt_self $axt_self.uniq.tp $axt_self.uniq.tp.ms $subDir/self* $subDir/hap.fa.media\n";

}
close ;
