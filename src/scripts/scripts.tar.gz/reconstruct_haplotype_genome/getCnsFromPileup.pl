#! /usr/bin/perl
use strict;

my $prefix = $ARGV[3];
open LOG1, " >$prefix.snp.log" or die $!;
open LOG2, " >$prefix.indel.log" or die $!;

my ($ctg,$seq);
$/ = ">";
open FA, $ARGV[2] or die $!;
<FA>;
while(<FA>){
	chomp;
	my @ctg_and_seq = split /\n+/, $_;
    $ctg = (split /\s+/, $ctg_and_seq[0])[0];
    for (my $i=1;$i<@ctg_and_seq;$i++){
	    $seq .= "$ctg_and_seq[$i]";
	}
}
close FA;
$/ = "\n";

open SNP, $ARGV[0] or die $!;
my %snp;
while(<SNP>){
	chomp;
#chr6_4  9165    G       G/C     2       G-1-HUMuvjD90poolingDFAAPEI-24_Index28_Index50_scaffold3|5713   C-1-HUMuvjD320poolingDFAAPEI-14_Inde	
	my $line = $_;
	my @tmp = split /\s+/, $line;
	my ($pos, $ref, $genotype) = @tmp[1,2,3];
	if ($ref eq "N" or $ref eq "n"){
		if ($genotype =~ /\//){
			$snp{$pos} = get_best_base($line);
		}else{
			$snp{$pos} = $genotype;
			print LOG1 "$pos:$ref->$genotype\n";
		}
	}elsif($ref =~ /[A|T|G|C|a|t|g|c]/){
		$snp{$pos} = get_best_base($line);
	}else{
		warn "Wrong base(can not match [A|T|G|C|a|t|g|c|N|n]') at $pos on the reference genome according to $ARGV[0]!\n";
	}
}
close SNP;

my (%ins,%del);
open INDEL, $ARGV[1] or die $!;
while(<INDEL>){
	chomp;
#chr6_4  18717   18717   1       1       TACAG   Tacag|3|572|28|HUMuvjD320poolingDFAAPEI-14_Index54_Index68_scaffold36
	my ($beg, $end, $ins_del, $detail, $against) = (split /\s+/, $_)[1,2,3,6,7];
	next if $against >1; #added at 2013/03/09 

	my @info = split /\//, $detail;

	my %num;
	my $skip =1;
	for (my $i=0; $i<@info; $i++){
		$info[$i] =~ /(\w+)\|(\d+)\|(\d+)\|(\d+)/;  #like: AC|0|3794|2515|HUMuvkD320poolingDFAAPEI-52_Index20_Index74_scaffold21
		my ($type,$dis) = ($1,$4);
		next if length $type >500;				#condition 1: the indel must be less than 500bp
		next if ($dis >0 and $dis <50);			#condition 2: the distance from nearest "N" must be larger than 50
		if ($ins_del eq "1"){
			next if $type =~ /[N|n]/;			#condition 3: can not match "N/n"
		}
		$num{$type}++;
		$skip =0;
	}
	next if $skip ==1;

	my $largest=0;
	my $best_type;
	foreach my $key (keys %num){
		if ($num{$key} > $largest){
			$best_type = $key;
			$largest = $num{$key};
		}
	}

	my $yes =0;
	if ($ins_del eq "1"){			#insertion
		if ($largest > $against and $largest > 1){
			$yes = 1;
		}
=head
		elsif($largest eq $against){
			my $ahead_seq = substr($seq, $beg-50, 50);
			my $back_seq  = substr($seq, $end, 50);
			if ($ahead_seq =~ /[NNNNNNNNNN|nnnnnnnnnn]/ or $back_seq =~ /[NNNNNNNNNN|nnnnnnnnnn]/){
				$yes = 1;
			}
		}
=cut
		if ($yes ==1){
			print LOG2 $_,"\n";
			$ins{$beg} .= "$best_type";
		}
	}elsif($ins_del eq "2"){		#deletion
		if ($largest > $against and $largest > 1){
			$yes = 1;
		}
=head
		elsif($largest eq $against){
			if ($best_type =~ /[NNNNNNNNNN|nnnnnnnnnn]/){
				$yes = 1;
			}else{
				my $ahead_seq = substr($seq, $beg-50, 50);
				my $back_seq  = substr($seq, $end, 50);
				if ($ahead_seq =~ /[NNNNNNNNNN|nnnnnnnnnn]/ or $back_seq =~ /[NNNNNNNNNN|nnnnnnnnnn]/){
					$yes = 1;
				}
			}
		}
=cut
		if ($yes == 1){
			print LOG2 $_,"\n";
			for(my $i=0;$i<length$best_type;$i++){
				my $tmp = $beg+$i;
				$del{$tmp} = "";
			}
		}
	}	
}
close INDEL;


#=========== deal pos one by one ======================
my $cor_seq;
for (my $i=0; $i<length$seq; $i++){
	my $pos = $i+1;
	my $base;
	$base = substr ($seq, $i, 1);
	if (exists $snp{$pos}){
		$base = $snp{$pos};
	}
	if (exists $ins{$pos}){
		$base .= $ins{$pos};
	}
	if (exists $del{$pos}){
		$base = $del{$pos};
	}
	$cor_seq .= "$base";
}
print ">$ctg\n$cor_seq\n";

#========== function to get the best single base ========
sub get_best_base{
	my $line = shift;
	my @tmp = split /\s+/, $line;
	my $pos = $tmp[1];
	my %num;
	for	(my $i=5; $i<@tmp; $i++){
		if ($tmp[$i] =~ /(\w+)-(\d+)-(.+)/){
			my ($type, $depth) = ($1,$2);
			$type =~ tr/atgc/ATGC/;
			$num{$type} = $depth;
		}else{
			warn "Wrong format at $pos column $i+1!\n";
		}
	}
	my $largest=0;
	my $best_base;
	foreach my $key (keys %num){
		if ($num{$key} > $largest){
			$best_base = $key;
			$largest = $num{$key};
		}
	}
	
	my $ref = $tmp[2];
	if ($ref =~ /[A|T|G|C|a|t|g|c]/){
		my $capital = $ref;
		$capital =~ tr/atgc/ATGC/;
		if (exists $num{$capital}){
			if ($num{$capital} == $largest){
				$best_base = $ref;
			}
		}
	}

	if ($best_base ne $ref){
		print LOG1 "$pos:$ref->$best_base\n";
	}

	return $best_base;
}
