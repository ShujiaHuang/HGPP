#!/usr/bin/perl 
#use strict;

unless(@ARGV==2)
{
	print "perl $0 in.site in.axt\n";
	exit;
}

my %record;
my %snp;
my %site;
open IN,"$ARGV[0]" or die "$!";
while(<IN>)
{
	chomp();
	my @field = split /\s+/;
	$snp{$field[0]}{$field[1]}[0] = $field[2]; # right position
	$snp{$field[0]}{$field[1]}[1] = $field[3]; # kind
	$snp{$field[0]}{$field[1]}[2] = $field[4]; # indel support number
	$snp{$field[0]}{$field[1]}[3] = $field[5]; # indel sequence
	$snp{$field[0]}{$field[1]}[4] = $field[6]; # indel support infor
	$snp{$field[0]}{$field[1]}[5] = 0; # Non indel support number
	$snp{$field[0]}{$field[1]}[6] = ""; # Non indel support infor
	push @{$site{$field[0]}},[$field[1],$field[2]];
}
close IN;

foreach my $chr(sort keys %site)
{
	@{$site{$chr}} = sort{$a->[0]<=>$b->[0]} @{$site{$chr}};
}

my $N=0;
my %axt;
my $start = 0;
open IN,"$ARGV[1]" or die "$!";
while(<IN>)
{
	next if(/^#/);
	my $ID = $_;
	my $ref= <IN>;
	my $asm= <IN>;
	<IN>;
	my @field = split /\s+/,$ID;
	my $first = 0;
	my @SNP;
#	print "$field[1]\t$field[2]\t$field[3]\t$field[4]\t$field[5]\t$field[6]\n";
	for(my $i=0;$i<@{$site{$field[1]}};$i++)
	{
#		if($site{$field[1]}[$i][1]>=$field[2] && $site{$field[1]}[$i][0]<=$field[3]) ## Overlap
		if($site{$field[1]}[$i][0]>=$field[2] && $site{$field[1]}[$i][1]<=$field[3]) ## Overlap
		{
#			$first = $i if($first == 0);
#			print "$site{$field[1]}[$i][0]\t$site{$field[1]}[$i][1]\n";
			push @SNP,$site{$field[1]}[$i][0];
		}
		elsif($site{$field[1]}[$i][0]> $field[3]) ## record site large than alignment site
		{
			last;
		}
	}
	if(@SNP >=1) ## With snp site in the alignment
	{
		my @ref = split //,$ref;
		my @asm = split //,$asm;
		my $td=0;
		my $rd=0;
		my $ad=0;
		for(my $j=0;$j<@SNP;$j++)
		{
			my $position = $SNP[$j];
#			print "Test\t$field[4]\t$position\n";
#			my $position2 = $site[$j][1];
			for(my $i=$td;$i<@ref;$i++)
			{
				if($position == $field[2]+$rd) ## one snp sit
				{
					my $base = $asm[$i];
					$base = uc $base;
					last if($base eq "N" || $base eq "-");
					my $posi = $field[5]+$ad;
					my $id = $field[4] . "|" . $posi;
#					print "get\t$position\t$base\t$id\n";
#					exit;
#					$record{$field[1]}{$position}{$base}[0]++;
#					if($record{$field[1]}{$position}{$base}[0]>1)
#					{
#						$record{$field[1]}{$position}{$base}[1] .= "" . "/" . $id;
#					}
#					else
#					{
#						$record{$field[1]}{$position}{$base}[1] = $id;
#					}
#					$record{$field[1]}
					if($snp{$field[1]}{$position}[4]!~/$field[4]/) ## with alignment which not support this indel
					{
						if($snp{$field[1]}{$position}[6])
						{
							$snp{$field[1]}{$position}[6] .= "/" . $field[4];
						}
						else
						{
							$snp{$field[1]}{$position}[6] = $field[4];
						}
						$snp{$field[1]}{$position}[5]++;
#						print "Not support $position\n";
					}
###### Test ###
#		else
#					{
#						print "support $position\n";
#					}
###### Test ###
#					print "Find $position\n";
					last;
				}
				if($ref[$i] ne "-")
				{
					$rd++;
				}
				if($asm[$i] ne "-")
				{
					$ad++;
				}
				$td++;
			}
		}
	}
	$start = $first;
}
close IN;
#exit;
foreach my $chr(sort %snp)
{
	foreach my $pos(sort{$a<=>$b} keys %{$snp{$chr}})
	{
#		my $key = keys %{$record{$chr}{$pos}};
#		print "$chr\t$pos\t$snp{$chr}{$pos}[0]\t$snp{$chr}{$pos}[1]\t$key";
#		foreach my $base(reverse sort {$record{$chr}{$pos}{$a}->[0]<=>$record{$chr}{$pos}{$b}->[0]} keys %{$record{$chr}{$pos}})
#		{
#			print "\t$base-$record{$chr}{$pos}{$base}[0]-$record{$chr}{$pos}{$base}[1]";
#		}
#		print "\n";
		print "$chr\t$pos\t$snp{$chr}{$pos}[0]\t$snp{$chr}{$pos}[1]\t$snp{$chr}{$pos}[2]\t$snp{$chr}{$pos}[3]\t$snp{$chr}{$pos}[4]\t$snp{$chr}{$pos}[5]\t$snp{$chr}{$pos}[6]\n"
	}
}
