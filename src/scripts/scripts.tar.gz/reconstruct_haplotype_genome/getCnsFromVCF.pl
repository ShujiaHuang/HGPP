#! /usr/bin/perl
use strict;

die "perl $0 <VCF> <FASTA> <abs_path_to_outdir/prefix>\n" unless @ARGV == 3;

#================ get the position of snp/insertion/deletion =============
open LOG1, " >$ARGV[2].final.snp.log" or die $!;
open LOG2, " >$ARGV[2].final.indel.log" or die $!;
my (%snp, %ins, %del);
open VCF, $ARGV[0] or die $!;
while(<VCF>){
	chomp;
	next if /^#/;
	my @tmp = split;
	#CHROM  POS     ID      REF     ALT     QUAL    FILTER  INFO    FORMAT  YH_fosmid
	#chr6_27 113     .       T       G       22      .       DP=22;AF1=0.5;CI95=0.5,0.5;DP4=15,0,6,0;MQ=53;FQ=25;PV4=1,8e-0
	#chr6_27 5194    .       CAG     CAGGCTGGGAG     214     .       INDEL;DP=24;AF1=1;CI95=1,1;DP4=0,0,4,16;MQ=47;FQ=-94.5
	my ($pos, $ref, $alt, $info) = @tmp[1,3,4,7];
	if ($info =~ /DP4=(\d+),(\d+),(\d+),(\d+)/){
		my $ref_dp = $1+$2;
		my $alt_dp = $3+$4;
		next unless $alt_dp > 5*$ref_dp;
	}else{
		warn "Wrong format of INFO at position:$pos in column 8!\n";
		next;
	}
	
	if ($alt =~ /,/){
		#chr6_10 779703  .       GAAAAAAAAAAAAAAAAA      GAAAAAAAAAAAAAAAAAAA,GAAAAAAAAAAAAAAAAAAAA,GAAAAAAAAAAAAAAAAAA  33.5    .  
		my $best_alt = (split /,/, $alt)[0];
		$alt = $best_alt;
	}

	my $ref_len = length $ref;
	my $alt_len = length $alt;

	if ($info=~ /^INDEL/){
		if ($ref_len eq $alt_len){
			warn "Is it not an INDEL at position $pos!\n";
			next;
		}elsif ($alt_len > $ref_len){   #insertion
			my $ins_len = $alt_len - $ref_len;
			my $ins_seq = substr ($alt, 1, $ins_len);
			$ins{$pos} .= "$ins_seq";
			print LOG2 "$pos\t+$ins_seq\n";
		}elsif ($alt_len < $ref_len){	#deletion
			my $del_len = $ref_len - $alt_len;
			for (my $i=1;$i<=$del_len; $i++){
				my $tmp = $pos + $i;
				$del{$tmp} = "";
			}
			print LOG2 "$pos\t-$del_len\n";
		}
	}else{
		if ($ref_len ne $alt_len){
			warn "It is not a SNP at position $pos!\n";
		}else{							#snp
			$snp{$pos} = $alt;
			print LOG1 "$pos\t$ref->$alt\n";
		}
	}
}
close VCF;
close LOG1;
close LOG2;

#======== read the ori fasta ================
my ($ctg,$seq);
$/ = ">";
open FA, $ARGV[1] or die $!;
<FA>;
while(<FA>){
	chomp;
	my @ctg_and_seq = split /\n+/, $_;
	$ctg = (split /\s+/, $ctg_and_seq[0])[0];
	for (my $i=1;$i<@ctg_and_seq;$i++){
		$seq .= "$ctg_and_seq[$i]";
	}
}
close FA;
$/ = "\n";


#===== deal base one by one to get the correlated sequence ==============
my $cor_seq;
for (my $i=0; $i<length$seq; $i++){
	my $pos = $i+1;
	my $base;
	$base = substr ($seq, $i, 1);
	if (exists $snp{$pos}){
		$base = $snp{$pos};
	}
	if (exists $ins{$pos}){
		$base .= $ins{$pos};
	}
	if (exists $del{$pos}){
		$base = $del{$pos};
	}
	$cor_seq .= "$base";
}
open OUT, " >$ARGV[2].final.fa" or die $!;
print OUT ">$ctg\n$cor_seq\n";
close OUT;

`fold $ARGV[2].final.fa >$ARGV[2].final.format.fa`;
`rm $ARGV[2].final.fa`;
