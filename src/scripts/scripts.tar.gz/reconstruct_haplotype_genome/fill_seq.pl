#! /usr/bin/perl
use strict;

open IN, $ARGV[0] or die $!;
my %hash;
while(<IN>){
	chomp;
	my $ctg = (split /\s+/, $_)[2];
	$hash{$ctg} = 1;
}
close IN;

open LIST, $ARGV[1] or die $!;
my %region;
while(<LIST>){
	chomp;
	my ($beg, $end) = split;
	$region{$beg} = $end;
}
close LIST;

open CLEAN," >$ARGV[3]" or die $!;
open TOTAL," >$ARGV[4]" or die $!;

open AXTBEST, $ARGV[2] or die $!;
my $count;
my $four_lines;
while(<AXTBEST>){
	next if /^#/;
	$count ++;
	if ($count%4 == 0){
		my @tmp = split /\n/, $four_lines;
		$four_lines = '';
		my ($first_line, $second_line, $third_line) = @tmp[0,1,2];
		my ($chr, $block_beg, $block_end, $ctg, $q_beg, $q_end, $block_ori) = (split /\s+/, $first_line)[1,2,3,4,5,6,7];
#		next if exists $hash{$ctg};
		foreach my $beg (sort {$a<=>$b} keys %region){
			my $end = $region{$beg};
			my $new_beg;
			my $new_end;
			my $sub_seq;
			unless ($block_beg > $end or $block_end < $beg){	
				if ($block_beg <= $beg and $block_end >= $beg and $block_end <= $end){
					my $ahead_len = get_ahead_len($beg, $block_beg, $second_line);
					my $sub_len = length($second_line) - $ahead_len;
					$sub_seq = substr ($third_line, $ahead_len, $sub_len);
					$sub_seq =~ s/-//g;
					($new_beg, $new_end) = ($beg, $block_end);
				}elsif($block_beg >=$beg and $block_end <= $end){
					$sub_seq = $third_line;
					$sub_seq =~ s/-//g;
					($new_beg, $new_end) = ($block_beg, $block_end);
				}elsif($block_beg >= $beg and $block_beg <= $end and $block_end >= $end){
					my $back_len = get_back_len($end, $block_end, $second_line);
					my $sub_len = length($second_line) - $back_len;
					$sub_seq = substr ($third_line, 0, $sub_len);
					$sub_seq =~ s/-//g;
					($new_beg, $new_end) = ($block_beg, $end);
				}elsif($block_beg <= $beg and $block_end >= $end){
					my $ahead_len = get_ahead_len($beg, $block_beg, $second_line);
					my $back_len  = get_back_len ($end, $block_end, $second_line);
					my $sub_len = length($second_line) - $ahead_len - $back_len;
					$sub_seq = substr ($third_line, $ahead_len, $sub_len);
					$sub_seq =~ s/-//g;
					($new_beg, $new_end) = ($beg, $end);
				}
				
				$sub_seq =~ tr/atgcn/ATGCN/; #use capital letters to represent the bases from YH1 contigs
				# Next, let's judge whether it is an inner-translocation...
				if (exists $hash{$ctg}){
					print TOTAL $new_beg,"\t",$new_end,"\t","inner-translocation","\t",$sub_seq,"\n";
				}else{
					print TOTAL $new_beg,"\t",$new_end,"\t",$ctg,"\t",$sub_seq,"\n";
					print CLEAN $new_beg,"\t",$new_end,"\t",$ctg,"\t",$sub_seq,"\n";
				}
			}
		}
		
	}else{
		$four_lines .= "$_";	
	}
}
close CLEAN;
close TOTAL;
close AXTBEST;

sub get_ahead_len{
	my ($beg, $block_beg, $second_line)	= @_;
	my $seq_len = $beg - $block_beg +1;
	my $overlap_len;
	my $pos = 0;

	my $len= length($second_line);
	for (my $i=0;$i<$len;$i++){
		my $base = substr($second_line,$i,1);
		if ($base ne "-"){
			$pos++;
		}
		if($pos == $seq_len){
		    $overlap_len = $i;
		    last;
		}
	}
	return $overlap_len;
}

sub get_back_len{
	my ($end, $block_end, $second_line) = @_;
	my $seq_len = $block_end - $end +1;
	my $overlap_len;
	my $pos = 0;
	my $len= length($second_line);
	for (my $i=$len-1;$i>=0;$i--){
		my $base = substr($second_line, $i,1);
		if ($base ne "-"){
			$pos++;
		}
		if ($pos == $seq_len){
			$overlap_len = $len - $i -1;
			last;
		}
	}
	return $overlap_len;
}
