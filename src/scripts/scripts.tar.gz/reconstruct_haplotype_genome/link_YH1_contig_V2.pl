#! /usr/bin/perl
use strict;


open TMP, $ARGV[2] or die $!;
my %hash;
while(<TMP>){
	chomp;
	my ($beg, $end , $ctg, $ctg_beg, $ctg_end, $ori, $last_end) = (split /\s+/, $_)[0..6];
	$hash{$ctg} = "$beg:$end:$ctg:$ctg_beg:$ctg_end:$ori:$last_end";
	if (/cut-\d+/){
		my $signal = (split /\s+/, $_)[7];
		$hash{$ctg} .= ":$signal";
	}
}
close TMP;

my %len;
open STAT, $ARGV[1] or die $!;
while(<STAT>){
	chomp;
	my @tmp = split;
	$len{$tmp[0]} = $tmp[1];
}
close STAT;

open AXT, $ARGV[0] or die $!;
my $count;
my $four_lines;
my (%final_ref_beg, %final_ref_end, %final_ctg_beg, %final_ctg_end);
while(<AXT>){
	next if /^#/;
	$count ++;
	if ($count%4 == 0){
		my @tmp = split /\n/, $four_lines;
		my ($first_line, $second_line, $third_line) = @tmp[0,1,2];
		my ($chr, $block_beg, $block_end, $ctg, $q_beg, $q_end, $block_ori) = (split /\s+/, $first_line)[1,2,3,4,5,6,7];	
		if(exists $hash{$ctg}){
			my ($beg, $end, $ctg_id, $ctg_beg, $ctg_end, $ori, $last_end) = (split /:/, $hash{$ctg})[0..6];
			if($block_ori eq $ori){
				unless($hash{$ctg} =~ /cut-\d+/){ # NOT end up with "cut:\d+"
					if ($last_end < $beg){
						print "$beg\t$end\t$ctg\t$ctg_beg\t$ctg_end\t$ori\n";	
						delete $hash{$ctg};
					}else{
						if ($block_beg <= $last_end and $block_end >= $last_end){
							#print $four_lines,"\n"; bug
							my $ahead_seq_len = get_ahead_len($last_end, $block_beg, $second_line, $third_line);					
							my ($new_beg, $new_end);
							if ($ori eq "+"){
								$new_beg = $q_beg + $ahead_seq_len;
								$new_end = $ctg_end;
							}elsif ($ori eq "-"){
								$new_beg = $ctg_beg;
								$new_end = ($len{$ctg} - $q_beg +1) - $ahead_seq_len;
							}
							print $last_end+1,"\t$end\t$ctg\t$new_beg\t$new_end\t$ori\n";
							delete $hash{$ctg};
						}
					}
				}else{						   # end up with "cut:\d+"
					my $signal = (split /:/, $hash{$ctg})[7];
					#print $signal,"\n"; bug
					$signal =~ /cut-(\d+)/;
					my $cut = $1;
					if ($last_end < $beg){
						$final_ref_beg{$ctg} = $beg;
						$final_ref_end{$ctg} = $cut;
						if ($block_beg <= $cut and $block_end >= $cut){
							my $back_seq_len = get_back_len($cut, $block_end, $second_line, $third_line);
							if ($ori eq "+"){
								$final_ctg_beg{$ctg} = $ctg_beg;
								$final_ctg_end{$ctg} = $q_end - $back_seq_len; #chaged from "ctg_end" => "$q_end", in 2013/03/09
							}elsif ($ori eq "-"){
								$final_ctg_beg{$ctg} = ($len{$ctg} - $q_end +1) + $back_seq_len;
								$final_ctg_end{$ctg} = $ctg_end;
							}
						}
					}else{
						$final_ref_beg{$ctg} = $last_end +1;
						$final_ref_end{$ctg} = $cut;
						if ($block_beg <= $last_end and $block_end >= $last_end){
							#print $four_lines,"\n"; bug
							my $ahead_seq_len = get_ahead_len($last_end, $block_beg, $second_line, $third_line);
							if ($ori eq "+"){
								$final_ctg_beg{$ctg} = $q_beg + $ahead_seq_len;
							}elsif ($ori eq "-"){
								$final_ctg_end{$ctg} = ($len{$ctg} - $q_beg +1) - $ahead_seq_len;
								#print $final_ctg_end{$ctg},"\n"; bug
							}
						}
						#print $block_beg,"\t",$cut,"\t",$block_end,"\n";bug
						if ($block_beg <= $cut and $block_end >= $cut){
							my $back_seq_len = get_back_len($cut, $block_end, $second_line, $third_line);
							if ($ori eq "+"){
								$final_ctg_end{$ctg} = $q_end - $back_seq_len;
							}elsif($ori eq "-"){
								$final_ctg_beg{$ctg} = ($len{$ctg} - $q_end +1) + $back_seq_len;
							}
						}
					}			
				}
			}
		}	
		$four_lines = '';		
	}else{
		$four_lines .= "$_";
	}
	
}
close AXT;

foreach my $ctg (keys %final_ref_beg){
	if (exists $final_ctg_beg{$ctg} and exists $final_ctg_end{$ctg}){
		my $ori = (split /:/, $hash{$ctg})[5];
		print "$final_ref_beg{$ctg}\t$final_ref_end{$ctg}\t$ctg\t$final_ctg_beg{$ctg}\t$final_ctg_end{$ctg}\t$ori\n";
	}
}

sub get_ahead_len{
    my ($beg, $block_beg, $second_line, $third_line) = @_;
    my $seq_len = $beg - $block_beg +1;
    my $overlap_len;
    my $pos = 0;
    my $len= length($second_line);
	for (my $i=0;$i<$len;$i++){
		my $base = substr($second_line,$i,1);
		if ($base ne "-"){
			$pos++;
		}
		if($pos == $seq_len){
			$overlap_len = $i;
			last;
		}
	}
	my $ahead_ref_len = $overlap_len +1; #diff from the script "fill_seq.pl"
	my $ahead_seq = substr($third_line,0,$ahead_ref_len);
	$ahead_seq =~ s/-//g;
	my $ahead_seq_len = length $ahead_seq;
	return $ahead_seq_len;	
}

sub get_back_len{
	my ($end, $block_end, $second_line, $third_line) = @_;
	my $seq_len = $block_end - $end +1;
	my $overlap_len;
	my $pos = 0;
	my $len= length($second_line);
	for (my $i=$len-1;$i>=0;$i--){
		my $base = substr($second_line, $i,1);
		if ($base ne "-"){
			$pos++;
		}
		if ($pos == $seq_len){
			$overlap_len = $len - $i -1;
			last;
		}
	}
	my $start = length($third_line) - $overlap_len;
	my $back_seq = substr($third_line, $start, $overlap_len);
	$back_seq =~ s/-//g;
	my $back_seq_len =0;
	$back_seq_len = length($back_seq);
	return $back_seq_len;
}
