#! /usr/bin/perl
use strict;

open TMP, $ARGV[0] or die $!;
my $last_end = 0;
my $largest = 0;
while(<TMP>){
	chomp;
	my @tmp = split;
	my ($beg,$end) = @tmp[0,1];
	if ($last_end +1 <= $beg -1){
		print $last_end+1, "\t", $beg-1,"\n";
	}
	$last_end = $end;
	$largest = $end if $largest < $end;
}
close TMP;

my $fa_stat = "/ifs1/ST_IM/USER/sunyuhui/software/fa_stat.pl";

my $bed = `$fa_stat $ARGV[1]`;
my $len = (split /\s+/,$bed)[1];

print $largest+1,"\t", $len,"\n" if $largest +1 <= $len;

