#! /usr/bin/perl
use strict;
no strict 'refs';

my $outDir = $ARGV[3];

my %haps;
open HAP, $ARGV[1] or die $!;
while(<HAP>){
	chomp;
	my @tmp = (split /\s+/,$_);
	my $hap = $tmp[0];
	next if $tmp[-1] eq "-";
	$haps{$hap} = 1;
}
close HAP;


my %hash;
my %hash2;
open LIST, $ARGV[0] or die $!;
while(<LIST>){
	chomp;
	my @tmp = split;

	my $hap = $tmp[0];
	next unless exists $haps{$hap};  #important
	my $subDir = "$outDir/$hap";
	mkdir $subDir unless -d $subDir; #creat dir to store the query.fa and target.fa

	my $fh = \*{$hap};
	open $fh, ">$subDir/$hap.query.fa" or die $!;

	my $contig_id = $tmp[2];
	#$hash{$contig_id} .= "$hap,";
	$hash{$contig_id}{$hap} = 1;
	my $pool = (split /_/,$contig_id)[0];
	$hash2{$pool} = 1;
}
close LIST;

my $YH1_FA = $ARGV[2];
$/ = ">";
open FA, $YH1_FA  or die $!;
<FA>;
while(<FA>){
	chomp;
	my @id_and_seq = split /\n/, $_;
	my $id = (split /\s+/, $id_and_seq[0])[0];
	my $seq;
	if (exists $hash{$id}){
		for (my $i=1;$i<@id_and_seq;$i++){
			$seq .= "$id_and_seq[$i]\n";
		}
		
		foreach my $hap (keys %{$hash{$id}}){
			my $fh = \*{$hap};
			print $fh ">$id\n$seq";
		}
		delete $hash{$id};
	}else{
		next;
	}
}
close FA;
$/ = "\n";


foreach my $ctg (keys %hash){
	warn "warning: $ctg sequence doesn't exist in $YH1_FA!\n";
}
