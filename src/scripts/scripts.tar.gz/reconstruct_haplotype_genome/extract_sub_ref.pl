#! /usr/bin/perl
use strict;


open BED, $ARGV[0] or die $!;
my %hash;
while(<BED>){
	chomp;
	my @tmp = split;
	my ($beg, $end) = @tmp[0,1];
	$hash{$beg} = $end;
}
close BED;

$/ = ">";
open FA, $ARGV[1] or die $!;
<FA>;
while(<FA>){
	chomp;
#$_ =~ s/\n//g;
#	$_ =~ /(.+\d+)(.+)/;
#	my $ref = "sub_$1";
#	my $seq = $2;
	my @tmp = split /\n+/, $_;
	my $ref = (split /\s+/, $tmp[0])[0];
	$ref = "sub_$ref";
	my $seq;
	for (my $i=1;$i<@tmp;$i++){
		$seq .= "$tmp[$i]";
	}
	foreach my $beg (sort {$a<=>$b} keys %hash){
		my $end = $hash{$beg};
		my $len = $end - $beg +1;
		my $sub_seq = substr($seq, $beg-1, $len);
		$sub_seq =~ tr/ATGCN/atgcn/; #use small letters to represent the bases from reference genome.
		print "$beg\t$end\t$ref\t$sub_seq\n";
	}
}
close FA;
